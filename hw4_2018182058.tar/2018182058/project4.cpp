#include <iostream>
#include <string>
#include <sstream>
#include <cmath>
#include <cstdlib>
#include <stdio.h>
#include <vector>

using namespace std;


class inode {
    public:
    int id;
    string name;
    int size;

    int directBlock;
    int singleIndirect;
    int doubleIndirect;

    inode() {
        id=-1;
        name="";
        size=-1;
        directBlock=-1;
        singleIndirect=-1;
        doubleIndirect=-1;
    }

};

class dentry {
    public :
    string name;
    int idx;
    int inodeIdx;

    dentry *parent;
    vector<dentry *> d_dentry;
    vector<inode *> d_inode;

    dentry() {
        name="";
        idx=0;
        inodeIdx=0;
        parent=NULL;
        d_dentry.reserve(64);
        d_inode.reserve(128);

    }

};


class super_block {
    public:
    dentry *s_root;
};


super_block sb;
dentry *curDir;

bool inodeTable[128];
int inodeSize=0;

int diskBlockSize=973;


void doLs() {
    for (int i=0; i<curDir->idx; i++) {
        printf("%s ", curDir->d_dentry[i]->name.c_str());
    }
    for (int i=0; i<curDir->inodeIdx; i++) {
        printf("%s ", curDir->d_inode[i]->name.c_str());
    }
    printf("\n");

}

void doCd(string word) {
   
    dentry *original=curDir;
    string s=word;
    string del="/";
    string token;
    size_t pos=0;
    bool error=false;
    // if ((pos=s.find(del))==string::npos) {
    //     // //cout<<pos<<endl;
    // }
    while ((pos=s.find(del))!=string::npos) {
        // //cout<<pos<<endl;
        if (pos==0) {
            curDir=sb.s_root;
            s.erase(0,pos+del.length());
            continue;
        }
        token=s.substr(0, pos);
        // //cout<<token<<endl;

        if (token=="..") {
            curDir=curDir->parent;
        } else if (token==".") {
            curDir=curDir;
        } else {
            bool find=false;
            for (int i=0; i<curDir->idx; i++) {
                if (token==curDir->d_dentry[i]->name) {
                    find=true;
                    curDir=curDir->d_dentry[i];
                    break;

                }
            }
            if (!find) {
                error=true;
                curDir=original;
                printf("error\n");
            }
        }
        s.erase(0,pos+del.length());
    }

    if (s.length()==0) {
        return;
    } else {
        if (s=="..") {
        curDir=curDir->parent;
        } else if (s==".") {
            curDir=curDir;
        } else {
            bool find=false;
            for (int i=0; i<curDir->idx; i++) {
                if (s==curDir->d_dentry[i]->name) {
                    find=true;
                    curDir=curDir->d_dentry[i];
                    // break;

                }
            }
            if (!find) {
                error=true;
                curDir=original;
                printf("error\n");
            }
        }

    }

    

}

void doMkdir(string word) {
    // //cout<<"----------------------"<<endl;
    // //cout<<word<<endl;
    string dirName=word;
    dentry *newDir;
    newDir=new dentry();
    newDir->name=dirName;
    newDir->parent=curDir;
   // dentry* ptr=&newDir;


    for (int i=0; i<curDir->idx; i++) {
        // //cout<<curDir->idx<<endl;
        // //cout<<curDir->d_dentry[i]->name<<endl;

        if (dirName==curDir->d_dentry[i]->name) {
            printf("error\n");
            return;
        }
    }


    //d_dentry add
    curDir->d_dentry.push_back(newDir);
    // delete ptr;
    curDir->idx++;

}

void checkDir(dentry dir) {
    if (dir.idx==0) {
        for (int j=0; j<dir.inodeIdx; j++) {
            diskBlockSize+=dir.d_inode[j]->directBlock;
            diskBlockSize+=dir.d_inode[j]->singleIndirect;
            diskBlockSize+=dir.d_inode[j]->doubleIndirect;
        }
        return;

    } else {

            for (int j=0; j<dir.inodeIdx; j++) {
                diskBlockSize+=dir.d_inode[j]->directBlock;
                diskBlockSize+=dir.d_inode[j]->singleIndirect;
                diskBlockSize+=dir.d_inode[j]->doubleIndirect;
            }
        for (int i=0; i<dir.idx; i++) {
            checkDir(*dir.d_dentry[i]);
        }
    }
}

void doRmdir(string word) {
    dentry emptyDir;
    // emptyDir.name="";
    bool exist=false;
    
    for (int i=0; i<curDir->idx; i++) {
        if (word==curDir->d_dentry[i]->name){
            exist=true;
            dentry tempDir=*curDir->d_dentry[i];
            // for (int j=0; j<tempDir.inodeIdx; j++) {
            //     diskBlockSize+=tempDir.d_inode[j]->directBlock;
            //     diskBlockSize+=tempDir.d_inode[j]->singleIndirect;
            //     diskBlockSize+=tempDir.d_inode[j]->doubleIndirect;
            // }

            checkDir(tempDir);
            // for (int j=0; j<tempDir.idx; j++) {
            //     checkDir(*tempDir.d_dentry[j]);
            // }

            curDir->idx--;
            curDir->d_dentry.erase(curDir->d_dentry.begin()+i);
            printf("Now you have ...\n");
            printf("%d / 973 (blocks)\n",diskBlockSize);
            break;
        }
    }

    if(!exist) {
        printf("error\n");
        return;
    }

}

void doMkfile(string word, int size) {
    // //cout<<size<<endl;
    string fname=word;
    int fsize=size;

    if (fsize<0) {
        printf("error\n");
        return;
    }


    inode *newInode;
    newInode=new inode();
  


    newInode->name=fname;
    newInode->size=fsize;
    newInode->directBlock=0;
    newInode->doubleIndirect=0;
    newInode->singleIndirect=0;


    for (int i=0; i<curDir->inodeIdx; i++) {
        if (fname==curDir->d_inode[i]->name) {
            printf("error\n");
            return;
        }
    }

    int bsize=0;
    if (fsize%1024!=0) {
        bsize=fsize/1024+1;
    } else {
        bsize=fsize/1024;
    }
    // int bsize=double(ceil(fsize/1024));
    // cout<<"here!!!!"<<bsize<<endl;

    if (bsize>diskBlockSize) {
        printf("error\n");

        return;
    }

    if (bsize<=12) {
        if (bsize>diskBlockSize) {
            printf("error\n");

            return;
        }
        for (int i=0; i<bsize; i++) {
            diskBlockSize--;
            newInode->directBlock++;
        }
    } else if ( bsize<=256+12) {
        if (bsize+1>diskBlockSize) {
        printf("error\n");

        return;
        }

        diskBlockSize--;
        newInode->singleIndirect++;
        newInode->directBlock=12;

        for (int i=0; i<bsize; i++) {
            diskBlockSize--;
            newInode->singleIndirect++;
        }
        newInode->singleIndirect-=12;

    } else {
        if (bsize+1+1+int(ceil((bsize-256-12)/256))>diskBlockSize) {
            printf("error\n");

            return;
        }
        // //cout<<"double entered"<<endl;
        diskBlockSize-=12;
        newInode->directBlock+=12;
        diskBlockSize-=257;
        newInode->singleIndirect+=257;

        diskBlockSize-=1;
        newInode->doubleIndirect+=1;

        if ((bsize-256-12)%256!=0) {

            diskBlockSize-=(bsize-256-12)/256+1;
            newInode->doubleIndirect+=(bsize-256-12)/256+1;
        } else {
            diskBlockSize-=(bsize-256-12)/256;
            newInode->doubleIndirect+=(bsize-256-12)/256;
        }


        diskBlockSize-=bsize-256-12;
        newInode->doubleIndirect+=bsize-256-12;


    }
    
    bool useOld=false;
    for (int i=0; i<inodeSize; i++) {
        if (!inodeTable[i]) {
            newInode->id=i;
            useOld=true;
            inodeTable[i]=true;
            break;
        }
    }
    if (!useOld) {
        newInode->id=inodeSize;
        inodeTable[inodeSize++]=true;
    }


    curDir->d_inode.push_back(newInode);
    curDir->inodeIdx++;
    // curDir->d_inode[curDir->inodeIdx++]=&newInode;

    printf("Now you have ...\n");
    printf("%d / 973 (blocks)\n", diskBlockSize);


}

void doRmfile(string fname) {
    bool exist=false;


    for (int i=0; i<curDir->inodeIdx; i++) {
        if (curDir->d_inode[i]->name==fname) {

            diskBlockSize+=curDir->d_inode[i]->directBlock;
            diskBlockSize+=curDir->d_inode[i]->singleIndirect;
            diskBlockSize+=curDir->d_inode[i]->doubleIndirect;

            inodeTable[curDir->d_inode[i]->id]=false;
            if (curDir->d_inode[i]->id==inodeSize) {
                inodeSize--;
            }

            curDir->inodeIdx--;
            curDir->d_inode.erase(curDir->d_inode.begin()+i);


            printf("Now you have ...\n");
            printf("%d / 973 (blocks)\n", diskBlockSize);

            exist=true;
            break;
        }
    }
    if (!exist) {
        printf("error\n");
        
        return;
    }

}

void doInode(string word) {
    bool exist=false;
    for (int i=0; i<curDir->inodeIdx; i++) {
        if (curDir->d_inode[i]->name==word) {
            exist=true;
            inode curInode=*curDir->d_inode[i];

            printf("ID: %d\nName: %s\nSize: %d (bytes)\n", curInode.id, curInode.name.c_str(), curInode.size);
            printf("Direct blocks: %d\n", curInode.directBlock);
            printf("Single indirect blocks: %d\n", curInode.singleIndirect);
            printf("Double indirect blocks: %d\n", curInode.doubleIndirect);

            break;
        }
    }
    if (!exist) {
        printf("error\n");
        
        return;
    }
}

// void doExit() {

// }


int main() {
   // fill_n(diskBlock, 1024, -1);
    dentry root;
    sb.s_root=&root;
    // dentry a;
   
    int s_id=2018182058;
    sb.s_root->name="";
    curDir=sb.s_root;
    // string current_path="";
    string input;

    while (true) {
        printf("%d:/%s$ ", s_id, curDir->name.c_str());

        getline(cin, input);
        stringstream ss(input);
        string word;

        ss>>word;
        // while(ss>>word) {
        if (word=="ls") {
            doLs();
        } else if (word=="cd") {
            ss>>word;
            doCd(word);
            
        } else if (word=="mkdir") {
            vector<string> slist;
            // slist=new vector<string>;
            bool error=false;
            while (ss>>word) {
                for (int j=0; j<curDir->idx; j++) {
                    if (word==curDir->d_dentry[j]->name) {
                        printf("error\n");
                        error=true;
                        break;
                    }
                }
                if (error) {
                    break;
                }
                slist.push_back(word);
            }
            if (!error) {
                for (int j=0; j<slist.size(); j++) {
                    doMkdir(slist[j]);
                }
            }
            slist.clear();
        } else if (word=="rmdir") {

            vector<string> slist;
            // slist=new vector<string>;
            bool error=false;
            bool find=false;
            while (ss>>word) {
                for (int j=0; j<curDir->idx; j++) {
                    if (word==curDir->d_dentry[j]->name) {
                        // printf("error\n");
                        // error=true;
                        find=true;
                        break;
                    }
                }
                if (!find) {
                    error=true;
                    printf("error\n");
                    break;
                }
                // if (error) {
                //     break;
                // }
                slist.push_back(word);
            }
            if (!error) {
                for (int j=0; j<slist.size(); j++) {
                    doRmdir(slist[j]);
                }
            }
            slist.clear();

            // while (ss>>word) {
            //     doRmdir(word);
            // }
        } else if (word=="mkfile") {
            ss>>word;
            string fname=word;
            ss>>word;
            int fsize=atoi(word.c_str());
            doMkfile(fname, fsize);
        } else if (word=="rmfile") {
            vector<string> slist;
            // slist=new vector<string>;
            bool error=false;
            bool find=false;
            while (ss>>word) {
                for (int j=0; j<curDir->inodeIdx; j++) {
                    if (word==curDir->d_inode[j]->name) {
                        find=true;
                        break;
                    }
                }
                if (!find) {
                    error=true;
                    printf("error\n");
                    break;
                }
                // if (error) {
                //     break;
                // }
                slist.push_back(word);
            }
            if (!error) {
                for (int j=0; j<slist.size(); j++) {
                    doRmfile(slist[j]);
                }
            }
            slist.clear();



            // while(ss>>word){
            //     doRmfile(word);
            // }
        } else if (word=="inode") {
            ss>>word;
            doInode(word);
        } else if (word=="exit") {
            break;
        } else {
            // printf("%d:%s/$ ", s_id, curDir->name.c_str());
        }

        continue;
        // }

    }

    return 0;
}


