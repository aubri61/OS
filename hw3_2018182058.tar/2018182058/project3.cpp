#include <iostream>
#include <string>
#include <cstring>
#include <stdio.h>
#include <fstream>
#include <unistd.h>
#include <sstream>
#include <vector>
#include <stdlib.h>
#include <memory.h>

#include "schedAl.h"
#include <queue>

using namespace std;
Process procList[2000000];
 

vector<pair<int, int> > optimalSimulator(vector<Process> procList, vector<inputInst> inputInstList, Options options, int procnum ) {
    vector<pair<int, int> > accessCodeList;

    int cycle=1;
    int aid=1;
    int pageFault=0;
    int *pageFalutPtr=&pageFault;
    int timeInterval=0;
    bool jobDone=false;
    queue<Process*> sleepList;
    queue<Process*> IOwaitList;
    queue<Process*> runQ;
    vector<LockVal> varlist;
    LockVal emptyVal;
    emptyVal.pid=-1;
    emptyVal.id=-1;
    emptyVal.locked=false;
    //bool varLockedList[20000];

    Process *runningProc;
    Process emptyProc;
    emptyProc.pid=-1;
    emptyProc.IOwait=false;
    emptyProc.done=false;
    emptyProc.busywaiting=false;
    inputInst curInst;
    codeInst curCode;
    codeInst emptyCode;
    bool scheduled=false;
    bool locked=false;
    bool busyWait=false;
    emptyCode.opcode=8;
    emptyCode.arg=0;

    //when input instruction is not given
    inputInst contInst;
    contInst.codename="continue";
    contInst.cycleTime=-1;
    contInst.IOpid=-1;

    runningProc=&emptyProc;

    // for (int z=0; z<26; z++) {
    while(!jobDone) {
         
        
        //check sleeplist proc job done if sleeplist is not empty
        if (!sleepList.empty()) {
            int size=sleepList.size();
            for(int i=0; i<size; i++) {
                Process *tempProc=sleepList.front();
                Process *resultP;
                tempProc->sleepCycle--;
                //sleep�� ����
                if (tempProc->sleepCycle==0) {
                    sleepList.pop();
                    tempProc->sleep=false;
                    if (options.sched=="sjf-simple") {
                       
                        tempProc->exBurst=calcExBurst(tempProc);
                        //when rup exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>tempProc->exBurst) {
                                runQ.push(runningProc);
                                runningProc=tempProc;
                                scheduled=true;
                                //break;

                            } else {
                                runQ.push(tempProc);
                            }
                        } else {
                            runQ.push(tempProc);

                        }
                    }
                    if (options.sched=="sjf-exponential") {
                      //  tempProc->preExBurst=tempProc->exBurst;
                        tempProc->exBurst=calcExBurstExp(tempProc);
                        //when rup exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>tempProc->exBurst) {
                                runQ.push(runningProc);
                                runningProc=tempProc;
                                scheduled=true;
                               // break;
                            

                            } else {
                                runQ.push(tempProc);
                            }
                        } else {
                            runQ.push(tempProc);

                        }

                    }
                    if (options.sched=="rr") {

                        tempProc->timeQuant=10;
                        tempProc->timeQuantAllUsed=false;
                    }
                   runQ.push(tempProc);
                } else {
                    sleepList.pop();
                    sleepList.push(tempProc);
                }
            }
        }



          if (runningProc->busywaiting && (options.sched=="sjf-simple" || options.sched=="sjf-exponential")) {
            if (!runQ.empty()) {
                int size=runQ.size();
                int min=8000000;
                Process *minP;
                for(int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();
                    //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                    
                    //sleep�� ����
                    if (tempProc->exBurst<min) {
                        //cout<<"here!!!!"<<endl;
                        min=tempProc->exBurst;
                        minP=tempProc;
                        runQ.pop();
                        runQ.push(tempProc);
                    } else {
                    
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                for (int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();

                    if (minP->pid==tempProc->pid) {
                        runningProc=tempProc;
                        runQ.pop();
                        //runQ.push(tempProc);
                    } else {
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                scheduled=true;
            }
        }


        //get curInstruction
        for(int i=0; i<options.totalEventNum; i++) {
            ////cout<<inputInstList[i].cycleTime<<endl;
            if (inputInstList[i].cycleTime==cycle) {
                ////cout<<"entered"<<endl;
                curInst=inputInstList[i];
                break;
            } else {
                curInst=contInst;
            }
        }


        //io task
        if (curInst.codename=="INPUT") {
            
            int curIOpid=curInst.IOpid;
       
            for (int i=0; i<IOwaitList.size(); i++) {
                Process *tempProc=IOwaitList.front();
                IOwaitList.pop();
                if (tempProc->pid==curIOpid) {
                    tempProc->IOwait=false;
                    if (options.sched=="sjf-simple") {
                        
                        tempProc->exBurst=calcExBurst(tempProc);
                        //when rup exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>tempProc->exBurst) {
                                runQ.push(runningProc);
                                runningProc=tempProc;
                                scheduled=true;
                               // break;
                            
                            } else {
                                runQ.push(tempProc);
                            }
                        } else {
                            runQ.push(tempProc);

                        }
                    }

                    if (options.sched=="sjf-exponential") {
                      //  tempProc->preExBurst=tempProc->exBurst;
                        tempProc->exBurst=calcExBurstExp(tempProc);
                        //when rup exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>tempProc->exBurst) {
                                runQ.push(runningProc);
                                runningProc=tempProc;
                                scheduled=true;
                              //  break;
                            

                            } else {
                                runQ.push(tempProc);
                            }
                        } else {
                            runQ.push(tempProc);

                        }
                        
                    }

                    if (options.sched=="rr") {

                        tempProc->timeQuant=10;
                        tempProc->timeQuantAllUsed=false;
                    }
                    runQ.push(tempProc);

                } else {
                    IOwaitList.push(tempProc);
                }
            }
        }


          if (runningProc->busywaiting && (options.sched=="sjf-simple" || options.sched=="sjf-exponential")) {
            if (!runQ.empty()) {
                int size=runQ.size();
                int min=8000000;
                Process *minP;
                for(int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();
                    //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                    
                    //sleep�� ����
                    if (tempProc->exBurst<min) {
                        //cout<<"here!!!!"<<endl;
                        min=tempProc->exBurst;
                        minP=tempProc;
                        runQ.pop();
                        runQ.push(tempProc);
                    } else {
                    
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                for (int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();

                    if (minP->pid==tempProc->pid) {
                        runningProc=tempProc;
                        runQ.pop();
                        //runQ.push(tempProc);
                    } else {
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                scheduled=true;
            }
        }

  
        if (curInst.cycleTime==cycle) {
            
            for (int i=0; i<procnum; i++) {
               if (procList[i].procName==curInst.codename) {
                    procList[i].created=true;
                    procList[i].vmptr=&procList[i].pageTable;
           
                    Process *tempP=&procList[i];
                  //  runQ.push(tempP);
                    if (options.sched=="sjf-simple" || options.sched=="sjf-exponential") {
                        bool change=false;
                        //if runninProc exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>5) {
                                runningProc->burstList.push_back(runningProc->burst);
                                runQ.push(runningProc);
                                change=true;
                                
                            } else {
                                runQ.push(tempP);
                            }
                        } else {
                            runQ.push(tempP);
                        }
                        if (change) {
                            runningProc=tempP;
                            scheduled=true;
                        }

                    } else {
                        runQ.push(tempP);
                    }
                    break;
               }
            }
        }

        //if running process empty get process from scheduler
        if(runningProc->pid==emptyProc.pid || runningProc->IOwait==true || runningProc->sleep==true) {
            //cout<<"choosing process~~~~~~~~~~~~~``"<<endl;
            if (options.sched=="fcfs"||options.sched=="rr") {
                if (!runQ.empty()) {
                    //cout<<"tehre"<<endl;
                    runningProc=runQ.front();
                    runningProc->timeQuantAllUsed=false;
                //  //cout<<runningProc->pid<<"       "<<runningProc->IOwait<<endl;
                    runQ.pop();
                    scheduled=true;
                } else {
                    //cout<<"it's empty............"<<endl;
                    runningProc=&emptyProc;
                    ////cout<<"here"<<endl;
                }
            } else if (options.sched=="sjf-simple"||options.sched=="sjf-exponential") {
                
                if (!runQ.empty()) {
                    int size=runQ.size();
                    int min=8000000;
                    Process *minP;
                    for(int i=0; i<size; i++) {
                        Process *tempProc=runQ.front();
                        //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                        
                        //sleep�� ����
                        if (tempProc->exBurst<min) {
                            //cout<<"here!!!!"<<endl;
                            min=tempProc->exBurst;
                            minP=tempProc;
                            runQ.pop();
                            runQ.push(tempProc);
                        } else {
                        
                            runQ.pop();
                            runQ.push(tempProc);
                        }
                    }

                    for (int i=0; i<size; i++) {
                        Process *tempProc=runQ.front();

                        if (minP->pid==tempProc->pid) {
                            runningProc=tempProc;
                            runQ.pop();
                            //runQ.push(tempProc);
                        } else {
                            runQ.pop();
                            runQ.push(tempProc);
                        }
                    }

                    scheduled=true;

                } else {
                    runningProc=&emptyProc;
                    ////cout<<"here"<<endl;
                }
            }


            if(runningProc->busywaiting) {
                int findingId=runningProc->lockingVal.id;
                for (int i=0; i<varlist.size(); i++) {
                    if (varlist[i].id==findingId) {
                        if (varlist[i].locked) {
                            break;
                        } else {
                            runningProc->busywaiting=false;
                            break;
                        }
                    }
                }
            }

        }
        
        if (runningProc->busywaiting && (options.sched=="sjf-simple" || options.sched=="sjf-exponential")) {
            if (!runQ.empty()) {
                int size=runQ.size();
                int min=8000000;
                Process *minP;
                for(int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();
                    //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                    
                    //sleep�� ����
                    if (tempProc->exBurst<min) {
                        //cout<<"here!!!!"<<endl;
                        min=tempProc->exBurst;
                        minP=tempProc;
                        runQ.pop();
                        runQ.push(tempProc);
                    } else {
                    
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                for (int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();

                    if (minP->pid==tempProc->pid) {
                        runningProc=tempProc;
                        runQ.pop();
                        //runQ.push(tempProc);
                    } else {
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                scheduled=true;
            }
        }

        //get the code for this cycle
        if (runningProc->pid!=emptyProc.pid) {
            if (runningProc->busywaiting) {
                //cout<<"waiting~~ for a  "<<runningProc->burst<<endl;
              //  //cout<<"program 1 exburst is "<<runQ.front()->exBurst<<endl;
                
                curCode=runningProc->codeList[runningProc->where-1];

                if(options.sched=="sjf-simple"||options.sched=="sjf-exponential") {
                    runningProc->burst++;
                }

                if(options.sched=="rr") {
                    runningProc->timeQuant--;
                }

                //when rr
                if(options.sched=="rr") {
                    if (runningProc->timeQuant==0 && runningProc->done==false) {
                        runningProc->timeQuant=10;
                        cout<<runningProc->pid<<"  has been pushed!!!  at cycle  "<<cycle<<endl;
                        runQ.push(runningProc);
                        runningProc->timeQuantAllUsed=true;
                    }
                }


            } else {
                if(options.page=="lru-sample"){
                    timeInterval++;
                }


                curCode=runningProc->codeList[runningProc->where];
                if (runningProc->where==runningProc->codeList.size()-1) {
                    runningProc->done=true;
                }
                runningProc->where++;

                if(options.sched=="sjf-simple"||options.sched=="sjf-exponential") {
                    runningProc->burst++;
                }
                if(options.sched=="rr") {
                    runningProc->timeQuant--;
                }


                switch (curCode.opcode) {
                    case 0 :
                    {
                        
                        aid++;
                        break;
                     
                    }
                    case 1 :
                    {
               

                        break;
                    }
                    case 2 : 
                    {
                 
                  
                        //cout<<"memory release"<<endl;
                        break;
                    }
                    case 3 :
                        //cout<<"non-memory instruction"<<endl;
                        break;

                    case 4 :
                        if (runningProc->done) {
                            //do nothing
                        } else {
                            runningProc->sleep=true;
                            runningProc->sleepCycle=curCode.arg;
                            sleepList.push(runningProc);
                            if (options.sched=="sjf-simple" || options.sched=="sjf-exponential") {
                                runningProc->burstList.push_back(runningProc->burst);
                                runningProc->preExBurst=runningProc->exBurst;
                                runningProc->burst=0;
                            }
                        }
                        //cout<<"sleep"<<endl;
                        break;


                    case 5 :
                        if (!runningProc->done) {
                            runningProc->IOwait=true;
                            IOwaitList.push(runningProc);
                            if (options.sched=="sjf-simple"||options.sched=="sjf-exponential") {
                                runningProc->burstList.push_back(runningProc->burst);
                                runningProc->preExBurst=runningProc->exBurst;
                                runningProc->burst=0;
                            }
                        }
                        //cout<<"IO Wait"<<endl;
                        break;


                    case 6 :
                    {   
                        //cout<<"------------now cycle is --------------   "<<cycle<<endl;
                        //cout<<"locking~~~~~~~~~~~~~~~~~~"<<endl;
                        bool exist=false;
                        int idx=0;
                        for (int i=0; i<varlist.size(); i++) {
                            if (varlist[i].id==curCode.arg) {
                                exist=true;
                                idx=i;
                                break;
                            }
                        }

                        if(exist) {
                            //cout<<"llllllllllllllllllllllllll"<<endl;
                            if(varlist[idx].locked) {
                                runningProc->busywaiting=true;
                             //   varlist[idx].
                                runningProc->lockingVal=varlist[idx];
                                //busyWait=true;
                            }
                        } else {
                            //cout<<"234342343242424324234"<<endl;

                            LockVal  v;
                            v.id=curCode.arg;
                            v.pid=runningProc->pid;
                            v.locked=true;
                            varlist.push_back(v);
                            runningProc->lockingVal=v;

                        }
                        break;
                    }

                    case 7 :
                    {
                        for (int i=0; i<varlist.size(); i++) {
                            if (varlist[i].id==curCode.arg) {
                                varlist[i].locked=false;
                                varlist[i].pid=-1;
                            }
                        }
                        runningProc->lockingVal=emptyVal;
                        break;
                    }
                }

                //when rr
                if(options.sched=="rr") {
                    if (runningProc->timeQuant==0 && runningProc->done==false) {
                        runningProc->timeQuant=10;
                        runQ.push(runningProc);
                        runningProc->timeQuantAllUsed=true;
                    }
                }
            }       

        } else {
            //cout<<"cur proc is empty            "<<endl;
            curCode=emptyCode;
            //cout<<curCode.opcode<<endl;
        }

        if (curCode.opcode==1) {
            accessCodeList.push_back(pair<int,int>(cycle, curCode.arg));
        }

        // //cout<<"--------------------cycle is :   "<<cycle<<"--------------------"<<endl;
        // ////cout<<"running proc is "<<runningProc->pid<<endl;
        //  ////cout<<"cur code is "<<curCode.opcode<<" "<<curCode.arg<<endl;
        //     ////cout<<"where? "<<runningProc->where<<endl;

        cycle++;
      
        if(sleepList.empty()&&IOwaitList.empty()&&runQ.empty()&&(runningProc->done==true)) {
            ////cout<<"1111111111111111111111"<<endl;
            jobDone=true;
            break;
        }
        scheduled=false;

        
        if(options.sched=="rr" && runningProc->timeQuantAllUsed==true) {

            ////cout<<"22222222222222222222222"<<endl;
            runningProc=&emptyProc;
        }

        if (runningProc->done) {
          
            ////cout<<"33333333333333333333333"<<endl;

            runningProc=&emptyProc;
        }

        if (runningProc->sleep==true) {
            runningProc=&emptyProc;
        }

    }
    
    return accessCodeList;
};



int main(int argc, char *argv[]) {
    //queue<pid_t> runQ;
    //�⺻�� ����
    Options options;
    options.dir="";
    options.sched="fcfs";
    options.page="fifo";
    string tempOption;
    int i=0;
    while(argv[i+1]!=NULL) {
        tempOption=argv[i+1];
        ////cout<<tempOption<<endl;
        if (tempOption.find("-sched")!=string::npos) {
            ////cout<<"sched endtered : "<<tempOption.substr(7)<<endl;
            options.sched=tempOption.substr(7);
        } else if (tempOption.find("-page")!=string::npos) {
            ////cout<<"page endtered : "<<tempOption.substr(6)<<endl;
            options.page=tempOption.substr(6);
        } else {
            ////cout<<"dir endtered : "<<tempOption.substr(5)<<endl;
            options.dir=tempOption.substr(5);
        }
        i++;
    }

    string inputFileDir=options.dir+"/input";
    ////cout<<"inputFileDir is "<<inputFileDir<<endl;

    FILE *input=fopen(inputFileDir.c_str(),"r");
    // ifstream input2;
    // input2.open(inputFileDir.c_str());
    FILE *outSched=fopen((options.dir+"/scheduler.txt").c_str(),"w");
    FILE *outMem=fopen((options.dir+"/memory.txt").c_str(),"w");

    fscanf(input, "%d\t%d\t%d\t%d\n", &options.totalEventNum, &options.vmemSize, &options.pmemSize, &options.pageSize);


    //getting input instrcutions

    char buffer[100];

    vector<inputInst> inputInstList;
    vector<inputInst> inputInstList2;

    int procnum=0;
    int sss=0;
    inputInstList.reserve(options.totalEventNum);
    for (i=0; i<options.totalEventNum; i++) {
        inputInst temp;
        fscanf(input, "%d\t%s\\s", &temp.cycleTime, (char*)&buffer);
        string str(buffer);
        temp.codename=str;
        if (temp.codename=="INPUT") {
           // //cout<<"entered"<<endl;
            fscanf(input, "%d\n", &temp.IOpid);
            temp.codename="INPUT";
           // //cout<<inputInstList[i].IOpid<<endl;
        } else {
            //fscanf(input, "\n", (char*)&buffer);
            procnum++;
            sss++;
        }
        inputInstList.push_back(temp);
    }

 //  Process procList2[sss];

  
   // hi(inputInstList);
    int idx=0;
    for (i=0; i<options.totalEventNum; i++) {
        if (inputInstList[i].codename!="INPUT") {

            FILE *fp=fopen((options.dir+"/"+inputInstList[i].codename).c_str(),"r");
            int num;
            fscanf(fp,"%d\n",&num);

            procList[idx].procName=inputInstList[i].codename;
            procList[idx].startTime=inputInstList[i].cycleTime;
            procList[idx].where=0;
            procList[idx].timeQuantAllUsed=false;
            procList[idx].timeQuant=10;
            procList[idx].IOwait=false;
            procList[idx].sleep=false;
            procList[idx].done=false;
            procList[idx].sleepCycle=0;
            procList[idx].pid=idx;
            procList[idx].created=false;
            procList[idx].busywaiting=false;
            procList[idx].burst=0;
            procList[idx].exBurst=5;
            procList[idx].pageTable.memSize=options.vmemSize/options.pageSize;
            procList[idx].pageTable.memTable.reserve(procList[idx].pageTable.memSize);
            

           // int zzsfsdfdsfa=0;
   //cout<<"hi"<<endl;

   
      
            for(int j=0; j<procList[idx].pageTable.memSize; j++) {
                procList[idx].pageTable.memTable[j].reserve(3);
                procList[idx].pageTable.memTable[j].push_back(-1);
                procList[idx].pageTable.memTable[j].push_back(-1);
                procList[idx].pageTable.memTable[j].push_back(0);    
            }


            procList[i].vmptr=&procList[i].pageTable;

       
            codeInst tempcode;
            ////cout<<"reaing the instrcutions~~~~~~~~~~~~~~~    "<<idx<<"  num   is   :  "<<num<<endl;
            for (int j=0; j<num; j++) {
                int a, b;
                fscanf(fp, "%d %d\n", &a, &b);
                //cout<<a<<"      "<<b<<endl;
                tempcode.opcode=a;
                tempcode.arg=b;
                procList[idx].codeList.push_back(tempcode);
                // fscanf(fp, "%d %d\n", &tempcode.opcode, &tempcode.arg);
                // procList[idx].codeList.push_back(tempcode);

            }
            idx++;
           // fclose(fp);
        } 
    }

    for (i=0; i<procnum; i++) {
        //cout<<procList[i].pid<<endl;
        for (int j=0; j<procList[i].codeList.size(); j++) {
            //cout<<procList[i].codeList[j].opcode<<" "<<procList[i].codeList[j].arg<<endl;
        }
        //cout<<"------------------------"<<endl;
    }
    // for (i=0; i<procnum; i++) {
    //     procList2[i]=procList[i];
    // }

    //cout<<"dafasdfd"<<endl;
    vector<Process> pvec;
    for (i=0; i<procnum; i++) {
        Process temp=procList[i];
        pvec.push_back(temp);
    }

    for (int i=0; i<procnum; i++) {
        //cout<<pvec[i].pid<<endl;
    }
  //  memcpy(procList2, procList, sizeof(procList));
    // //memcpy(inputInstList2, inputInstList, inputInstList.size());
    // inputInstList2.resize(options.totalEventNum);
    // copy(inputInstList.begin(), inputInstList.end(), inputInstList2.begin());
    //cout<<"here??"<<endl;
   // Process * ptttt=&procList;

    // //cout<<"aaaaa"<<endl;
    vector<pair<int, int> > accessCodeList=optimalSimulator(pvec, inputInstList, options, procnum);
    // // vector<pair<int, int> > tttt;
   scheduler(procList, inputInstList, options, procnum, outSched, outMem, accessCodeList);
    //cout<<";;;;;;;;;;;;;;;;;;;;;;;"<<endl;
   // delete[] procList;
    return 0;
}


