#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <sstream>
#include <typeinfo>

#include <unistd.h>
#include <stdio.h>
#include "schedAl.h"
#include "buddy.h"



int calcExBurst(Process *proc) {
    int sum=0;
    //cout<<"------------------calculating exburst--------------"<<endl;
        //cout<<proc->pid<<"      has   "<<proc->burstList.size()<<"   bursts"<<endl;
    for (int i=0; i<proc->burstList.size(); i++) {
        sum+=proc->burstList[i];
        //cout<<proc->burstList[i]<<" sum is    "<<sum<<endl;
    }
    return sum/(proc->burstList.size());
}

int calcExBurstExp(Process *proc) {
    double result=0.6*(proc->burstList[proc->burstList.size()-1]) + 0.4*(proc->preExBurst);
    return (int)result;
}

void scheduler(Process *procList, vector<inputInst> inputInstList, Options options, int procnum, FILE *schedout, FILE *memout, vector<pair<int, int> > accessCodeList) {

    int cycle=1;
    int aid=1;
    int pageFault=0;
    int *pageFalutPtr=&pageFault;
    int timeInterval=0;
    bool jobDone=false;
    queue<Process*> sleepList;
    queue<Process*> IOwaitList;
    queue<Process*> runQ;
    vector<LockVal> varlist;
    LockVal emptyVal;
    emptyVal.pid=-1;
    emptyVal.id=-1;
    emptyVal.locked=false;
    //bool varLockedList[20000];

    Process *runningProc;
    Process emptyProc;
    emptyProc.pid=-1;
    emptyProc.IOwait=false;
    emptyProc.done=false;
    inputInst curInst;
    codeInst curCode;
    codeInst emptyCode;
    bool scheduled=false;
    bool locked=false;
    bool busyWait=false;
    emptyCode.opcode=8;
    emptyCode.arg=0;

    //when input instruction is not given
    inputInst contInst;
    contInst.codename="continue";
    contInst.cycleTime=-1;
    contInst.IOpid=-1;

    //ó������ �̷��� ���� ����
    runningProc=&emptyProc;
    Memory VM;
    VM.memSize=options.vmemSize/options.pageSize;
    VM.memTable.reserve(VM.memSize);
  
    for(int i=0; i<VM.memSize; i++) {
        VM.memTable[i].reserve(3);
        VM.memTable[i].push_back(-1);
        VM.memTable[i].push_back(-1);
        VM.memTable[i].push_back(0);
    }
   // createTable(options.vmemSize, options.pageSize, false, VM);
    Memory PM;
    PM.memSize=options.pmemSize/options.pageSize;
    PM.memTable.reserve(PM.memSize);
    for(int i=0; i<PM.memSize; i++) {
        PM.memTable[i].reserve(3);
        PM.memTable[i].push_back(-1);
        PM.memTable[i].push_back(i);
        PM.memTable[i].push_back(0);
    }
   // createTable(options.pmemSize, options.pageSize, true, PM);
    Memory *pmptr=&PM;
    Buddy buddy(PM);


    vector<pair<int, int> > aidPair;
    //vector<Process*> pageTableList;


    while(!jobDone) {

        
        //check sleeplist proc job done if sleeplist is not empty
        if (!sleepList.empty()) {
            int size=sleepList.size();
            for(int i=0; i<size; i++) {
                Process *tempProc=sleepList.front();
                Process *resultP;
                tempProc->sleepCycle--;
                //sleep�� ����
                if (tempProc->sleepCycle==0) {
                    sleepList.pop();
                    tempProc->sleep=false;
                    if (options.sched=="sjf-simple") {
                       
                        tempProc->exBurst=calcExBurst(tempProc);
                        //when rup exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>tempProc->exBurst) {
                                runQ.push(runningProc);
                                runningProc=tempProc;
                                scheduled=true;
                                //break;
                            

                            } else {
                                runQ.push(tempProc);
                            }
                        } else {
                            runQ.push(tempProc);

                        }
                    }
                    if (options.sched=="sjf-exponential") {
                      //  tempProc->preExBurst=tempProc->exBurst;
                        tempProc->exBurst=calcExBurstExp(tempProc);
                        //when rup exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>tempProc->exBurst) {
                                runQ.push(runningProc);
                                runningProc=tempProc;
                                scheduled=true;
                               // break;
                            

                            } else {
                                runQ.push(tempProc);
                            }
                        } else {
                            runQ.push(tempProc);

                        }

                    }
                    if (options.sched=="rr") {

                        tempProc->timeQuant=10;
                        tempProc->timeQuantAllUsed=false;
                    }
                   runQ.push(tempProc);
                } else {
                    sleepList.pop();
                    sleepList.push(tempProc);
                }
            }
        }

               if (runningProc->busywaiting && (options.sched=="sjf-simple" || options.sched=="sjf-exponential")) {
            if (!runQ.empty()) {
                int size=runQ.size();
                int min=8000000;
                Process *minP;
                for(int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();
                    //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                    
                    //sleep�� ����
                    if (tempProc->exBurst<min) {
                        //cout<<"here!!!!"<<endl;
                        min=tempProc->exBurst;
                        minP=tempProc;
                        runQ.pop();
                        runQ.push(tempProc);
                    } else {
                    
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                for (int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();

                    if (minP->pid==tempProc->pid) {
                        runningProc=tempProc;
                        runQ.pop();
                        //runQ.push(tempProc);
                    } else {
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                scheduled=true;
            }
        }


        //get curInstruction
        for(int i=0; i<options.totalEventNum; i++) {
            ////cout<<inputInstList[i].cycleTime<<endl;
            if (inputInstList[i].cycleTime==cycle) {
                ////cout<<"entered"<<endl;
                curInst=inputInstList[i];
                break;
            } else {
                curInst=contInst;
            }
        }


        //io task
        if (curInst.codename=="INPUT") {
            timeInterval++;

            int curIOpid=curInst.IOpid;
       
            for (int i=0; i<IOwaitList.size(); i++) {
                Process *tempProc=IOwaitList.front();
                IOwaitList.pop();
                if (tempProc->pid==curIOpid) {
                    tempProc->IOwait=false;
                    if (options.sched=="sjf-simple") {
                        //cout<<"this cycle is -------------"<<cycle<<endl;

                        tempProc->exBurst=calcExBurst(tempProc);
                        //when rup exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>tempProc->exBurst) {
                                runQ.push(runningProc);
                                runningProc=tempProc;
                                scheduled=true;
                               // break;
                            
                            } else {
                                runQ.push(tempProc);
                            }
                        } else {
                            runQ.push(tempProc);

                        }
                    }

                    if (options.sched=="sjf-exponential") {
                      //  tempProc->preExBurst=tempProc->exBurst;
                        tempProc->exBurst=calcExBurstExp(tempProc);
                        //when rup exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>tempProc->exBurst) {
                                runQ.push(runningProc);
                                runningProc=tempProc;
                                scheduled=true;
                              //  break;
                            

                            } else {
                                runQ.push(tempProc);
                            }
                        } else {
                            runQ.push(tempProc);

                        }
                        
                    }

                    if (options.sched=="rr") {

                        tempProc->timeQuant=10;
                        tempProc->timeQuantAllUsed=false;
                    }
                    runQ.push(tempProc);

                } else {
                    IOwaitList.push(tempProc);
                }
            }
        }

        if(options.page=="lru-sample"&&timeInterval==8) {
            buddy.refPush();
            timeInterval=0;
        }



        if (runningProc->busywaiting && (options.sched=="sjf-simple" || options.sched=="sjf-exponential")) {
            if (!runQ.empty()) {
                int size=runQ.size();
                int min=8000000;
                Process *minP;
                for(int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();
                    //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                    
                    //sleep�� ����
                    if (tempProc->exBurst<min) {
                        //cout<<"here!!!!"<<endl;
                        min=tempProc->exBurst;
                        minP=tempProc;
                        runQ.pop();
                        runQ.push(tempProc);
                    } else {
                    
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                for (int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();

                    if (minP->pid==tempProc->pid) {
                        runningProc=tempProc;
                        runQ.pop();
                        //runQ.push(tempProc);
                    } else {
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                scheduled=true;
            }
        }



     
        //input given process creation
        if (curInst.cycleTime==cycle) {
            
            for (int i=0; i<procnum; i++) {
               if (procList[i].procName==curInst.codename) {
                    procList[i].created=true;
                    procList[i].vmptr=&procList[i].pageTable;
           
                    Process *tempP=&procList[i];
                  //  runQ.push(tempP);
                    if (options.sched=="sjf-simple" || options.sched=="sjf-exponential") {
                        bool change=false;
                        //if runninProc exist
                        if (runningProc->pid!=emptyProc.pid) {
                            if ((runningProc->exBurst-runningProc->burst)>5) {
                                runningProc->burstList.push_back(runningProc->burst);
                                runQ.push(runningProc);
                                change=true;
                                
                            } else {
                                runQ.push(tempP);
                            }
                        } else {
                            runQ.push(tempP);
                        }
                        if (change) {
                            runningProc=tempP;
                            scheduled=true;
                        }

                    } else {
                        runQ.push(tempP);
                    }
                    break;
               }
            }
        }
        ////cout<<"4444444444444444444444"<<endl;
            


               if (runningProc->busywaiting && (options.sched=="sjf-simple" || options.sched=="sjf-exponential")) {
            if (!runQ.empty()) {
                int size=runQ.size();
                int min=8000000;
                Process *minP;
                for(int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();
                    //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                    
                    //sleep�� ����
                    if (tempProc->exBurst<min) {
                        //cout<<"here!!!!"<<endl;
                        min=tempProc->exBurst;
                        minP=tempProc;
                        runQ.pop();
                        runQ.push(tempProc);
                    } else {
                    
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                for (int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();

                    if (minP->pid==tempProc->pid) {
                        runningProc=tempProc;
                        runQ.pop();
                        //runQ.push(tempProc);
                    } else {
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                scheduled=true;
            }
        }




        //if running process empty get process from scheduler
        if(runningProc->pid==emptyProc.pid || runningProc->IOwait==true || runningProc->sleep==true) {
            if (options.sched=="fcfs"||options.sched=="rr") {
                if (!runQ.empty()) {
                    ////cout<<"tehre"<<endl;
                    runningProc=runQ.front();
                    runningProc->timeQuantAllUsed=false;
                //  //cout<<runningProc->pid<<"       "<<runningProc->IOwait<<endl;
                    runQ.pop();
                    scheduled=true;
                } else {
                    runningProc=&emptyProc;
                    ////cout<<"here"<<endl;
                }
            } else if (options.sched=="sjf-simple"||options.sched=="sjf-exponential") {
                //cout<<"cur cycle is ================ "<<cycle<<endl;
                if (!runQ.empty()) {
                    int size=runQ.size();
                    int min=8000000;
                    Process *minP;
                    for(int i=0; i<size; i++) {
                        Process *tempProc=runQ.front();
                        //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                        
                        //sleep�� ����
                        if (tempProc->exBurst<min) {
                            //cout<<"here!!!!"<<endl;
                            min=tempProc->exBurst;
                            minP=tempProc;
                            runQ.pop();
                            runQ.push(tempProc);
                        } else {
                            //cout<<"no!!!!!!!"<<endl;

                            runQ.pop();
                            runQ.push(tempProc);
                        }
                    }
                        //cout<<"minP is "<<minP->pid<<"   "<<minP->exBurst<<endl;


                    for (int i=0; i<size; i++) {
                        Process *tempProc=runQ.front();

                        if (minP->pid==tempProc->pid) {
                            runningProc=tempProc;
                            runQ.pop();
                            //runQ.push(tempProc);
                        } else {
                            runQ.pop();
                            runQ.push(tempProc);
                        }
                    }

                    scheduled=true;

                } else {
                    runningProc=&emptyProc;
                    ////cout<<"here"<<endl;
                }
            }


            if(runningProc->busywaiting) {
                int findingId=runningProc->lockingVal.id;
                for (int i=0; i<varlist.size(); i++) {
                    if (varlist[i].id==findingId) {
                        if (varlist[i].locked) {
                            break;
                        } else {
                            runningProc->busywaiting=false;
                            break;
                        }
                    }
                }
            }


        }

        if (runningProc->busywaiting && (options.sched=="sjf-simple" || options.sched=="sjf-exponential")) {
            if (!runQ.empty()) {
                int size=runQ.size();
                int min=8000000;
                Process *minP;
                for(int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();
                    //cout<<"curProc is "<<tempProc->pid<<"   "<<tempProc->exBurst<<endl;
                    
                    //sleep�� ����
                    if (tempProc->exBurst<min) {
                        //cout<<"here!!!!"<<endl;
                        min=tempProc->exBurst;
                        minP=tempProc;
                        runQ.pop();
                        runQ.push(tempProc);
                    } else {
                    
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                for (int i=0; i<size; i++) {
                    Process *tempProc=runQ.front();

                    if (minP->pid==tempProc->pid) {
                        runningProc=tempProc;
                        runQ.pop();
                        //runQ.push(tempProc);
                    } else {
                        runQ.pop();
                        runQ.push(tempProc);
                    }
                }

                scheduled=true;
            }
        }


        //get the code for this cycle
        if (runningProc->pid!=emptyProc.pid) {
            if (runningProc->busywaiting) {
                
                curCode=runningProc->codeList[runningProc->where-1];

                if(options.sched=="sjf-simple"||options.sched=="sjf-exponential") {
                    runningProc->burst++;
                }

                if(options.sched=="rr") {
                    runningProc->timeQuant--;
                }

                //when rr
                if(options.sched=="rr") {
                    if (runningProc->timeQuant==0 && runningProc->done==false) {
                        runningProc->timeQuant=10;
                        runQ.push(runningProc);
                        runningProc->timeQuantAllUsed=true;
                    }
                }


            } else {
                if(options.page=="lru-sample"){
                    timeInterval++;
                }


                curCode=runningProc->codeList[runningProc->where];
                if (runningProc->where==runningProc->codeList.size()-1) {
                    runningProc->done=true;
                }
                runningProc->where++;

                if(options.sched=="sjf-simple"||options.sched=="sjf-exponential") {
                    runningProc->burst++;
                }
                if(options.sched=="rr") {
                    runningProc->timeQuant--;
                }
                ////cout<<runningProc->pid<<endl;


                switch (curCode.opcode) {
                    case 0 :
                    {
                        for (int i=0; i<runningProc->pageTable.memSize; i++) {
                        //   //cout<<runningProc->pageTable.memTable[i][0]<<endl;
                            if (runningProc->pageTable.memTable[i][0]==-1) {
                                for (int j=0; j<curCode.arg; j++) {
                                    runningProc->pageTable.memTable[i+j][0]=aid;
                                    runningProc->pageTable.memTable[i+j][1]=-1;
                                    runningProc->pageTable.memTable[i+j][2]=0;
                                }
                                // int x=curCode.opcode;
                                // //cout<<"x is  "<<x<<endl;
                                aidPair.push_back(pair<int, int>(aid, curCode.arg));
                                
                                aid++;
                                break;
                            }
                        }
                    
                        
                        ////cout<<"memory allocation"<<endl;
                        break;
                    }
                    case 1 :
                    {
                    //cout<<"now is "<<cycle<<"------------------"<<endl;
                    for (int i=0; i<buddy.pages.size(); i++) {
                        //cout<<buddy.pages[i].aid<<endl;
                        for (int j=0; j<8; j++) {
                            //cout<<buddy.pages[i].refByte.front()<<" ";
                            int t=buddy.pages[i].refByte.front();
                            buddy.pages[i].refByte.pop();
                            buddy.pages[i].refByte.push(t);

                        }
                        //cout<<endl;
                    }
                        
                        int size=0;
                        int idx=0;

                        for (int i=0; i<runningProc->pageTable.memSize; i++) {
                            if (runningProc->pageTable.memTable[i][0]==curCode.arg) {
                                idx=i;
                                break;
                            }
                        }

                        // //cout<<"idx is "<<idx<<endl;

                        for (int i=0; i<aidPair.size(); i++) {
                            if (aidPair[i].first==curCode.arg) {
                                size=aidPair[i].second;
                                break;
                            }
                        }
                        if (runningProc->pageTable.memTable[idx][2]==1) {
                            //cout<<"touched"<<endl;
                            //touch
                            buddy.touch(curCode.arg);
                        } else {
                            //cout<<"allocating~~~~~~~~~~~~~~`"<<endl;

                        //  //cout<<"j;joijoijoijoijojojoijoijoiojioj"<<endl;
                            int how=buddy.allocatePM(pmptr, size, runningProc->vmptr, curCode.arg, idx, options, accessCodeList, cycle) ;
                            pageFault+=how;
                            
                        }

                        for (int i=0; i<size; i++) {
                            runningProc->pageTable.memTable[idx+i][2]=1;
                        }


                        //if other pro flushed
                        // vector<int> pmAidList;
                        // for (int i=0; i<PM.memSize; i++) {
                        //     if (PM.memTable[i][0]!=-1) {
                        //         for (int j=0; j<pmAidList.size(); j++) {

                        //             if (pmAidList[j]==PM.memTable[i][0]) {
                        //                 break;
                        //             } else {
                        //                 pmAidList.push_back(PM.memTable[i][0]);
                        //                 break;
                        //             }
                        //         }
                        //     }
                        // }
                            

                        // for (int i=0; i<pmAidList.size(); i++) {
                        //     cout<<pmAidList[i]<<" "<<endl;
                        // }

                        // for (int i=0; i<procnum; i++) {
                        //     for (int j=0; j<procList[i].pageTable.memSize; j++) {
                        //         for (int k=0; k<pmAidList.size(); k++) {
                        //             if (procList[i].pageTable.memTable[i][0]==pmAidList[k]) {
                        //                 procList[i].pageTable.memTable[i][2]=0;
                        //             }
                        //         }
                                
                        //     }
                        // }
                        // pmAidList.clear();

                        break;
                    }
                    case 2 : 
                    {
                    ////cout<<"now is "<<cycle<<"------------------"<<endl;
                        ////cout<<"releasing@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"<<endl;
                        int size=0;
                        int idx=0;
                        bool exist=false;
                        for (int i=0; i<buddy.pages.size(); i++) {
                            if (buddy.pages[i].aid==curCode.arg) {
                                exist=true;
                            }
                        }
                        for (int i=0; i<VM.memSize; i++) {
                            if (runningProc->pageTable.memTable[i][0]==curCode.arg) {
                                int j=i;
                                idx=i;
                                while(runningProc->pageTable.memTable[j][0]==curCode.arg) {
                                    runningProc->pageTable.memTable[j][0]=-1;
                                    runningProc->pageTable.memTable[j][2]=0;

                                    size++;
                                    j++;
                                }
                                break;
                            }
                        }
                        if (exist) {
                            buddy.releaseMem(pmptr, runningProc->vmptr, curCode.arg);
                        } else {
                            //do nothing.
                        }
                      
                        break;
                    }
                    case 3 :
                        //////cout<<"non-memory instruction"<<endl;
                        break;

                    case 4 :
                        if (runningProc->done) {
                            //do nothing
                        } else {
                            runningProc->sleep=true;
                            runningProc->sleepCycle=curCode.arg;
                            sleepList.push(runningProc);
                            if (options.sched=="sjf-simple" || options.sched=="sjf-exponential") {
                                runningProc->burstList.push_back(runningProc->burst);
                                runningProc->preExBurst=runningProc->exBurst;
                                runningProc->burst=0;
                            }
                        }
                        //////cout<<"sleep"<<endl;
                        break;


                    case 5 :
                        if (!runningProc->done) {
                            runningProc->IOwait=true;
                            IOwaitList.push(runningProc);
                            if (options.sched=="sjf-simple"||options.sched=="sjf-exponential") {
                                runningProc->burstList.push_back(runningProc->burst);
                                runningProc->preExBurst=runningProc->exBurst;
                                runningProc->burst=0;
                            }
                        }
                        //////cout<<"IO Wait"<<endl;
                        break;


                    case 6 :
                    {   
                        ////cout<<"------------now cycle is --------------   "<<cycle<<endl;
                        ////cout<<"locking~~~~~~~~~~~~~~~~~~"<<endl;
                        bool exist=false;
                        int idx=0;
                        for (int i=0; i<varlist.size(); i++) {
                            if (varlist[i].id==curCode.arg) {
                                exist=true;
                                idx=i;
                                break;
                            }
                        }

                        if(exist) {
                            ////cout<<"llllllllllllllllllllllllll"<<endl;
                            if(varlist[idx].locked) {
                                runningProc->busywaiting=true;
                             //   varlist[idx].
                                runningProc->lockingVal=varlist[idx];
                                //busyWait=true;
                            }
                        } else {
                            ////cout<<"234342343242424324234"<<endl;

                            LockVal  v;
                            v.id=curCode.arg;
                            v.pid=runningProc->pid;
                            v.locked=true;
                            varlist.push_back(v);
                            runningProc->lockingVal=v;

                        }
                        break;
                    }


                    case 7 :
                    {
                        for (int i=0; i<varlist.size(); i++) {
                            if (varlist[i].id==curCode.arg) {
                                varlist[i].locked=false;
                                varlist[i].pid=-1;
                            }
                        }
                        runningProc->lockingVal=emptyVal;
                        break;
                    }
                }

                if(timeInterval==8 && options.page=="lru-sample") {
                    buddy.refPush();
                    timeInterval=0;
                }

                //when rr
                if(options.sched=="rr") {
                    if (runningProc->timeQuant==0 && runningProc->done==false) {
                        runningProc->timeQuant=10;
                        runQ.push(runningProc);
                        runningProc->timeQuantAllUsed=true;
                    }
                }
            }       

        } else {
            ////cout<<"cur proc is empty            "<<endl;
            curCode=emptyCode;
            ////cout<<curCode.opcode<<endl;
        }



        //file printing
        fprintf(schedout, "[%d Cycle] Scheduled Process: ", cycle);

        if (scheduled) {
            //////cout<<runningProc->procName<<endl;
            fprintf(schedout, "%d %s\n", runningProc->pid, runningProc->procName.c_str());
        } else {
            fprintf(schedout, "None\n");
        }
        //////cout<<"6666666666666666"<<endl;


        fprintf(schedout, "Running Process: ");
        if (runningProc->pid!=emptyProc.pid) {
            //fprintf(schedout, "Process#%d running code %s line %d(op %d, arg %d)  cur Proc job done?(%d)\n", runningProc->pid, runningProc->procName.c_str(), runningProc->where, curCode.opcode, curCode.arg, runningProc->done);

            //fprintf(schedout, "Process#%d running code %s line %d(op %d, arg %d)  time quantum left is %d  time quantum used is %d\n", runningProc->pid, runningProc->procName.c_str(), runningProc->where, curCode.opcode, curCode.arg, runningProc->timeQuant,runningProc->timeQuantAllUsed);
            
            fprintf(schedout, "Process#%d running code %s line %d(op %d, arg %d)\n", runningProc->pid, runningProc->procName.c_str(), runningProc->where, curCode.opcode, curCode.arg);
        } else {
            fprintf(schedout, "None\n");
        }
        //////cout<<"7777777777"<<endl;
        //////cout<<"runq empty?  "<<runQ.empty()<<endl;

        fprintf(schedout, "RunQueue: ");
        if (runQ.empty()) {
            fprintf(schedout, "Empty");
        } else {
            for (int i=0; i<runQ.size(); i++) {
                //////cout<<"runQ now "<<runQ.front().procName<<endl;
                fprintf(schedout, "%d(%s) ",runQ.front()->pid,runQ.front()->procName.c_str());
                Process *tempProc=runQ.front();
                runQ.pop();
            //////cout<<"012342342314"<<endl;
                runQ.push(tempProc);
            }
        }
        fprintf(schedout, "\n");

        ////cout<<"8888888888888"<<endl;



        fprintf(schedout, "SleepList: ");
        if (sleepList.empty()) {
            fprintf(schedout, "Empty");
        } else {
            for (int i=0; i<sleepList.size(); i++) {
                fprintf(schedout, "%d(%s) ",sleepList.front()->pid, sleepList.front()->procName.c_str());
                Process *tempProc=sleepList.front();
                sleepList.pop();
                sleepList.push(tempProc);
            }
        }
        fprintf(schedout, "\n");


        fprintf(schedout, "IOWait List: ");
        if (IOwaitList.empty()) {
            fprintf(schedout, "Empty");
        } else {
            for (int i=0; i<IOwaitList.size(); i++) {
                fprintf(schedout, "%d(%s) ",IOwaitList.front()->pid,IOwaitList.front()->procName.c_str());
                Process *tempProc=IOwaitList.front();
                IOwaitList.pop();
                IOwaitList.push(tempProc);
            }
        }
        fprintf(schedout, "\n");
        fprintf(schedout, "\n");






       //cout<<"888888888888888888888"<<endl;

        
        //memory.txt print
        if (runningProc->pid==-1) {
            //cout<<"SIBBBBBBAAAAAALLLLLLLL"<<endl;
            fprintf(memout, "[%d Cycle] Input : Function [NO-OP]\n", cycle);
        } else {

            if (runningProc->busywaiting) {
                fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s]\n", cycle, runningProc->pid, "LOCK");

            } else {
                switch (curCode.opcode){
                    case 0 :
                    {
                        int taid;
                        for (int i=0; i<aidPair.size(); i++) {
                            if (aidPair[i].second==curCode.arg) {
                                taid=aidPair[i].first;
                                break;
                            }
                        }
                        fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s] Alloc ID [%d] Page Num[%d]\n", cycle, runningProc->pid, "ALLOCATION", aid-1, curCode.arg);
                        break;
                    }
                    case 1 :
                    {
                        int pagenum;
                        for (int i=0; i<aidPair.size(); i++) {
                            if (aidPair[i].first==curCode.arg) {
                                pagenum=aidPair[i].second;
                                break;
                            }
                        }
                        fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s] Alloc ID [%d] Page Num[%d]\n", cycle, runningProc->pid, "ACCESS", curCode.arg, pagenum);

                        break;
                    }
                    case 2 :
                    {
                        int pagenum;
                        for (int i=0; i<aidPair.size(); i++) {
                            if (aidPair[i].first==curCode.arg) {
                                pagenum=aidPair[i].second;
                                break;
                            }
                        }
                        fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s] Alloc ID [%d] Page Num[%d]\n", cycle, runningProc->pid, "RELEASE", curCode.arg, pagenum);

                        break;
                    }
                    case 3 :
                        fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s]\n", cycle, runningProc->pid, "NONMEMORY");

                        //fprintf(memout, "[%d Cycle] Input : Function [NONMEMORY]\n", cycle);
                        break;


                    case 4 :
                        fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s]\n", cycle, runningProc->pid, "SLEEP");
                        break;
                        
                    
                    case 5 :
                        fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s]\n", cycle, runningProc->pid, "IOWAIT");
                        break;
                        
                    case 6 :
                        fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s]\n", cycle, runningProc->pid, "LOCK");

                        break;
                        
                    case 7 :
                        fprintf(memout, "[%d Cycle] Input : Pid [%d] Function [%s]\n", cycle, runningProc->pid, "UNLOCK");

                        break;
                    // case 8 :
                    //     fprintf(memout, "[%d Cycle] Input : Function [NO-OP]\n", cycle);

                    //     break;
                        
                    }
            }
        }

        //line2
      
        string pmstring="";
        for (int i=0; i<PM.memSize; i++) {
            if (i%4==0) {
                pmstring+="|";
            }
            if (PM.memTable[i][0]!=-1) {
                stringstream ss;
                ss<<PM.memTable[i][0];
                pmstring+=ss.str();

                //pmstring+=PM.memTable[i][0];
            } else {
                pmstring+="-";
            }
        }
        pmstring+="|";
        fprintf(memout, "%-30s",">> Physical Memory : ");
        fprintf(memout, "%s\n", pmstring.c_str());

        // //cout<<pmstring<<endl;


        ////cout<<"1010100110101101011010"<<endl;




        //line3
        for (int i=0; i<procnum; i++) {
            if ( procList[i].created==false) {
                continue;
            } else if (procList[i].done==true && procList[i].pid!=runningProc->pid) {
                continue;
            }
            else {
                string vmstring="";
                string vmval="";
                for (int j=0; j<VM.memSize; j++) {
                    ////cout<<"entered"<<endl;
                    if (j%4==0) {
                        vmstring+="|";
                        vmval+="|";

                       // //cout<<vmstring<<endl;
                    }
                    if (procList[i].pageTable.memTable[j][0]!=-1) {
                        stringstream ss;
                        ss<<procList[i].pageTable.memTable[j][0];
                        vmstring+=ss.str();

                        stringstream dd;
                        dd<<procList[i].pageTable.memTable[j][2];
                        vmval+=dd.str();
                       
                        continue;

                    } else {
                        vmstring+="-";
                        vmval+="-";
                        continue;
                    }
            ////cout<<"adfadfadsf"<<endl;
                }
               
                vmstring+="|";
                vmval+="|";
              
                
                fprintf(memout, ">> pid(%d) %-20s",procList[i].pid, "Page Table(AID) : ");
                fprintf(memout, "%s\n", vmstring.c_str());
                fprintf(memout, ">> pid(%d) %-20s",procList[i].pid, "Page Table(Valid) : ");
                fprintf(memout, "%s\n", vmval.c_str());
                // //cout<<"VM pid is "<<procList[i].pid<<" ----------------"<<endl;
                // //cout<<vmstring<<endl;
                // //cout<<vmval<<endl;
            }
        }
        fprintf(memout,"\n");




        cycle++;
        
        if(sleepList.empty()&&IOwaitList.empty()&&runQ.empty()&&(runningProc->done==true)) {
            jobDone=true;

            break;
        }
        scheduled=false;

        
        if(options.sched=="rr" && runningProc->timeQuantAllUsed==true) {
            runningProc=&emptyProc;
        }

        if (runningProc->done) {
            //cout<<"cur cycle is "<<cycle<<"----------------------- cur proc is done : "<<runningProc->pid<<endl;
           

            vector<int> tempList;
            // int taid=-2000;
            for (int i=0; i<runningProc->pageTable.memSize; i++) {
                if (runningProc->pageTable.memTable[i][2]==1) {
                    for (int j=0; j<tempList.size(); j++) {
                        if (tempList[j]==runningProc->pageTable.memTable[i][0]) {
                            break;
                        } else {
                            tempList.push_back(runningProc->pageTable.memTable[i][0]);
                            break;
                        }
                    }
                }
           
            }

            //cout<<pmstring<<endl;


         //   for (int i=0; i<)

            for (int i=0; i<tempList.size(); i++) {
                ////cout<<tempList[i]<<endl;
                buddy.eraseMem(pmptr, tempList[i], runningProc->vmptr);

                //cout<<"done!!!!! one cycle!!!!!   "<<endl;
            //    //cout<<pmstring<<endl;
            }

            runningProc=&emptyProc;
        }

        if (runningProc->sleep==true) {
            runningProc=&emptyProc;
        }
     
        ////cout<<runningProc->pid<<"       "<<runningProc->IOwait<<endl;

    }
    
        //last line
        fprintf(memout, "page fault = %d\n", pageFault);
                        //cout<<"++++++++++++++;+++++++++"<<endl;
};

