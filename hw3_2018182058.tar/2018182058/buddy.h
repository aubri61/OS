#ifndef BUDDY
#define BUDDY

#include "options.h"
#include "memory.h"
#include <queue>
#include <cmath>
#include <string>

class Node {
public :
    int aid, start, end, size, binSize;
    Node *left;
    Node *right;
    Node *root;
    Node *parent;

    Node() {
        left=NULL;
        right=NULL;
        root=NULL;
        parent=NULL;
        aid=-1;
        start=0;
        end=0;
        size=0;
     //   binSize=0;
    }

    Node(int a, int b, int c, int d) {
        aid=a;
        start=b;
        end=c;
        size=d;

    
    }

};

class Buddy {
    public :
        Node root;
        Node *rootPtr;
    
        Memory backingStore;

        struct Pages{
            Node *PMblock;
            int time;
            int aid;
            queue<int> refByte;
            int r;
            int opt;
            int count;
        };

        vector<Pages> pages;
        queue<int> zeroQ;


        Buddy(Memory PM) {
            root.start=0;
            root.end=PM.memSize-1;
            root.size=PM.memSize;
            rootPtr=&root;
            for (int i=0; i<8; i++) {
                zeroQ.push(0);
            }
        }

        void refPush() {
            for (int i=0; i<pages.size(); i++) {
                pages[i].refByte.pop();
                pages[i].refByte.push(pages[i].r);
                pages[i].refByte.back()=pages[i].r;
                pages[i].r=0;
            }
            for (int i=0; i<pages.size(); i++) {
                ////cout<<pages[i].aid<<"    :   "<<pages[i].r<<endl;
                for (int j=0; j<8; j++) {
                    int temp=pages[i].refByte.front();
                    pages[i].refByte.pop();
                    ////cout<<temp<<" ";
                    pages[i].refByte.push(temp);
                }
                ////cout<<endl;
            }
        }

        void split(Node *parent) {
            parent->left=new Node(-1, parent->start, parent->start+parent->size/2-1, parent->size/2);
            parent->right=new Node(-1, parent->start+parent->size/2, parent->end, parent->size/2);
            
            parent->left->parent=parent;
            parent->right->parent=parent;
            parent->aid=0;
            //////cout<<"llllllllllll"<<endl;
        }

        void merge(Node *a, Memory *PM, Memory *VM) {
            Node *x=a;
            Node *y;
            while(mergeCheck(PM, VM, x)) {
            
                x->parent->aid=-1;
                x->parent->left=NULL;
                x->parent->right=NULL;
               
                if (x->parent->size!=PM->memSize) {
                    x=x->parent;
                  
                    continue;

                } else {
                    break;
                }
            }
        }


        Node* search(Node* root, int demandSize, int aid) {
            //////cout<<"search entered"<<endl;
            queue<Node*> bq;
            bq.push(root);
            Node *temp;
            bool result=false;
            Node emptyNode;
            emptyNode.aid=-10;
            Node *enptr;
            enptr=&emptyNode;
            ////cout<<"adjfasdfasdfadfs"<<endl;
            queue<Node*> avail;
            bool smallerEx=false;
            bool notSplit=false;

            while(!bq.empty()) {
                temp=bq.front();
                ////cout<<"aid is ~~~~~~~`   "<<temp->aid<<endl;
                bq.pop();
                if (temp->aid>0) {
                    ////cout<<"filled"<<endl;
                    continue;
                    //return false;
                } else if (temp->aid==-1) {
                    
                    if (binaryCheck(temp->size,demandSize)) {
                        ////cout<<"empty and fit"<<endl;
                        
                       return temp;
                    } else {
                        ////cout<<"empty but size no fit"<<endl;

                        if (!bq.empty()&&bq.front()->aid==0) {

                            if (bq.front()->left->aid==0) {
                                smallerEx=true;
                                return bq.front()->left;
                            } else if(bq.front()->right->aid==0){
                                smallerEx=true;
                                return bq.front()->right;
                            } else {
                                smallerEx=false;
                            }

                        } else {

                            if (!bq.empty()) {
                                if (bq.front()->size==temp->size) {

                                    split(temp);
                                    
                                    bq.push(temp->left);
                                    bq.push(temp->right);    
                                } else {
                                    Node *tt=search(temp->parent->left, demandSize, aid);
                                    int ttaid=tt->aid;
                                    if (ttaid==-10) {
                                        split(temp);
                                        
                                        bq.push(temp->left);
                                        bq.push(temp->right);   
                                    } else {
                                        continue;
                                    }
                                }
                            } else {
                                split(temp);
                               
                                bq.push(temp->left);
                                bq.push(temp->right); 
                            }

                     

                        }

                    }
                } else {
                    if (binaryCheck(temp->size, demandSize)) {
                        if (bq.empty()) {
                            break;
                        } else {

                            if ( bq.front()->aid==-1) {

                                continue;
                            } else {
                                break;
                                //return enptr;

                            }
                        }
                    } else {


                        //check children
                        bq.push(temp->left);
                        bq.push(temp->right);
                        
                    }
                }
            }
            return enptr;

            // }
        }


        bool binaryCheck(int a, int demandSize) {
            if (demandSize>a/2 && demandSize<=a) {
                return true;
            } else {
                return false;
            }
        }

        void fillMem(Node *node, Memory *PM, Memory *VM, int idx) {
            for (int i=0; i<node->size; i++) {
                PM->memTable[node->start+i][0]=node->aid;
                PM->memTable[node->start+i][2]=1;
                
            }
        }

        void flushMem(Memory *PM, Memory *VM, Node *block) {

            ////cout<<"entered flushcMem*****************************        "<<endl;
           // ////cout<<"hi    "<<endl;
            int oriAid=block->aid;
            block->aid=-1;
        //    ////cout<<block->start<<"   "<<block->end<<endl;
            for (int i=block->start; i<=block->end; i++) {
                PM->memTable[i][0]=-1;
                PM->memTable[i][2]=0;
            }

            for (int i=0; i<VM->memSize; i++) {
                if (VM->memTable[i][0]==oriAid) {
                    VM->memTable[i][2]=0;
                    VM->memTable[i][1]=-1;
                }
            }
       

        }

        void eraseMem(Memory *PM, int aid, Memory *VM) {
            //cout<<"how much page do you have???????????   "<<pages.size()<<endl;
            for (int i=0; i<pages.size(); i++) {
                if (pages[i].aid==aid) {
                    //cout<<"now page aid is "<<pages[i].aid<<endl;
                    //cout<<"now page block is "<<pages[i].PMblock->aid<<endl;

                    pages[i].PMblock->aid=-1;
            
                    int start=pages[i].PMblock->start;
                    int end=pages[i].PMblock->end;
                    for (int j=start; j<=end; j++) {
                        //cout<<"entered"<<endl;
                        PM->memTable[j][0]=-1;
                        PM->memTable[j][2]=0;
                    }
                    //cout<<"sibal"<<endl;
                    if ( mergeCheck(PM, VM, pages[i].PMblock) ) {
                    //cout<<"merge!!!!!!!!!!!!!!! done and merge!!!!!!!!!!!!!!!!!!"<<endl;
                        merge(pages[i].PMblock, PM, VM);
                    }
                    pages.erase(pages.begin()+i);
                }
            }
            //cout<<"erase done"<<endl;
            for (int i=0; i<PM->memSize; i++) {
                for (int j=0; j<3; j++) {
                    //cout<<PM->memTable[i][j]<<" ";
                }
                //cout<<endl;
            }
        }

        void releaseMem(Memory *PM, Memory *VM, int aid) {
            Node *temp;
            ////cout<<"aid needed is "<<aid<<endl;
            int idx=0;
            for (int i=0; i<pages.size(); i++) {
            }
            for (int i=0; i<pages.size(); i++) {
                if (pages[i].aid==aid) {
                    
                    idx=i;
                    temp=pages[i].PMblock;
                break;
                }
            }
          
            flushMem(PM, VM, temp);
            if ( mergeCheck(PM, VM, temp) ) {
                merge(temp, PM, VM);
            }
            pages.erase(pages.begin()+idx);
            //cout<<"adfasdfasfdfs"<<endl;
        }

        bool mergeCheck(Memory *PM, Memory *VM, Node *block) {
      
            if (block->size==PM->memSize) {
                //cout<<"no parent"<<endl;
                return false;
            } else {

                        //cout<<"cur block is "<<block->start<<" "<<block->end<<endl;
                if ( block->parent->left->aid ==block->aid ) {
                    if (block->parent->right->aid==-1) {
                       
                        return true;
                    } else {
                        //cout<<"yes parent"<<endl;
                        return false;
                    }
                } else {
                    if (block->parent->left->aid==-1) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        }

        void touch(int aid) {
            int one=1;
            for (int i=0; i<pages.size(); i++) {
                if (pages[i].aid==aid) {
                    pages[i].time=0;
                    pages[i].r=one;
                    pages[i].count++;
                } else {
                    pages[i].time++;

                }
            }
        }

        int allocatePM(Memory *PM, int demandSize, Memory *VM, int aid, int idx, Options options, vector<pair<int, int> > accessCodeList, int cycle) {
            for (int i=0; i<pages.size(); i++) {
                pages[i].time++;
            }
            Node *result=search(rootPtr, demandSize, aid);
            int resAid=result->aid;
            int pageF=0;
            int zero=0;
            int one=1;
            
            if ( resAid!=-10) {
                result->aid=aid;
                //cout<<"yes space"<<endl;
                fillMem(result, PM, VM, idx);
                Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=one;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                pageF++;
          
                

            } else {
                //cout<<"no space"<<endl;

                if (options.page=="fifo") {
                    pageF=fifo(PM, VM , demandSize, aid, idx);
                } else if (options.page=="lru") {
                    pageF=lru(PM, VM , demandSize, aid, idx);
                } else if (options.page=="lru-sample") {
                    pageF=lruS(PM, VM, demandSize, aid, idx);
                } else if (options.page=="lfu") {
                    pageF=lfu(PM, VM, demandSize, aid, idx);
                } else if (options.page=="mfu") {
                    pageF=mfu(PM, VM, demandSize, aid, idx);
                } else if (options.page=="optimal") {
                    pageF=optimal(PM, VM, demandSize, aid, idx, accessCodeList, cycle);
                }
              
            }
            return pageF;
        }

        Pages chooseOptimal(vector<pair<int, int> > accessCodeList, int cycle) {
            vector<pair<int, int> >::iterator it;
            int idx=0;
            for (int i=0; i<accessCodeList.size(); i++) {
                if (accessCodeList[i].first==cycle) {
                    idx=i;
                    break;
                }
            }
            int zero=0;

            int count=0;
            for (int i=idx+1; i<accessCodeList.size(); i++) {
                //cout<<accessCodeList[i].first<<"    :   "<<accessCodeList[i].second<<endl;
                count++;
                int taid=accessCodeList[i].second;
                for (int j=0; j<pages.size(); j++) {
                    if (pages[j].aid==taid && pages[j].opt==0) {
                        pages[j].opt=count;
                    }
                }
            }
            //cout<<"pringting optimal counts~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
            for (int i=0; i<pages.size(); i++) {
                //cout<<pages[i].aid<<"   "<<pages[i].opt<<endl;
            }

            bool check=false;
            for (int i=0; i<pages.size(); i++) {
                if (pages[i].opt==0) {
                    check=true;
                    break;
                }
            }

            Pages tp;
            if (check) {
                int minAid=200000;
                for (int i=0; i<pages.size(); i++) {
                    if (pages[i].opt==0) {
                        if (pages[i].aid<minAid) {
                            minAid=pages[i].aid;
                            tp=pages[i];
                            idx=i;
                        }
                    }
                }
            } else {
                int max=-1;
                idx=0;
                for (int i=0; i<pages.size(); i++) {
                    if (pages[i].opt>max) {
                        max=pages[i].opt;
                        tp=pages[i];
                        idx=i;
                    } else if (pages[i].opt==max) {
                        if (pages[i].aid<tp.aid) {
                            tp=pages[i];
                            idx=i;
                        }
                    }
                }
            }
            pages.erase(pages.begin()+idx);
            for (int i=0; i<pages.size(); i++) {
                pages[i].opt=zero;
            }

            for (int i=0; i<pages.size(); i++) {
                //cout<<pages[i].aid<<"   "<<pages[i].opt<<endl;
            }

            return tp;
        }

        int optimal(Memory *PM, Memory *VM, int demandSize, int aid, int idx, vector<pair<int, int> > accessCodeList, int cycle) {
            int how=0; 
            while (true) {
                how++;
                //cout<<"~!#!@#~@!#~@!#~@#~@!#~@!#"<<endl;
                //cout<<pages.size()<<endl;
                Pages tp=chooseOptimal(accessCodeList, cycle);
                //cout<<tp.PMblock->start<<endl;
                //cout<<tp.PMblock->end<<endl;

                tp.PMblock->aid=-1;
                flushMem(PM, VM, tp.PMblock);
                if ( mergeCheck(PM, VM, tp.PMblock)) {
                    merge(tp.PMblock, PM, VM);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                        Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=1;
               // pages.back().refByte=zeroQ;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                } else {
                    flushMem(PM, VM, tp.PMblock);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                        Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=1;
               // pages.back().refByte=zeroQ;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                }
            }
            return how;
        
        }

        Pages chooseMfu() {
            int max=-1;
            Pages tp;
            int idx=0;

            for (int i=0; i<pages.size(); i++) {
                if (pages[i].count>max) {
                    max=pages[i].count;
                    tp=pages[i];
                    idx=i;
                } else if (pages[i].count==max) {
                    if (pages[i].aid<tp.aid) {

                        tp=pages[i];
                        idx=i;
                    }
                }
            }
            pages.erase(pages.begin()+idx);

            return tp;
        }

        int mfu(Memory *PM, Memory *VM, int demandSize, int aid, int idx) {
            int how=0; 
            while (true) {
                how++;
                Pages tp=chooseMfu();
                tp.PMblock->aid=-1;
                flushMem(PM, VM, tp.PMblock);
                if ( mergeCheck(PM, VM, tp.PMblock)) {
                    merge(tp.PMblock, PM, VM);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                       Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=1;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                } else {
                    flushMem(PM, VM, tp.PMblock);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                         Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                pages.back().r=1;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                }
            }
            return how;
        
        }

        Pages chooseLfu() {
            int min=200000;
            Pages tp;
            int idx=0;
            ////cout<<"choose lfu page"<<endl;
            for (int i=0; i<pages.size(); i++) {
                ////cout<<"page aid is : "<<pages[i].aid<<" //   count is :  "<<pages[i].count<<endl;
            }

            for (int i=0; i<pages.size(); i++) {
                if (pages[i].count<min) {
                    min=pages[i].count;
                    tp=pages[i];
                    idx=i;
                } else if (pages[i].count==min) {
                    if(pages[i].aid<tp.aid){

                        tp=pages[i];
                        idx=i;
                    }
                }
            }
            pages.erase(pages.begin()+idx);
            ////cout<<"result is   : "<<tp.aid<<endl;
            return tp;
        }

        int lfu(Memory *PM, Memory *VM, int demandSize, int aid, int idx) {
            int how=0; 
            while (true) {
                how++;
                Pages tp=chooseLfu();
                tp.PMblock->aid=-1;
                flushMem(PM, VM, tp.PMblock);
                if ( mergeCheck(PM, VM, tp.PMblock)) {
                    merge(tp.PMblock, PM, VM);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                         Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                pages.back().r=1;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                } else {
                    flushMem(PM, VM, tp.PMblock);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                         Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=1;
               // pages.back().refByte=zeroQ;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                }
            }
            return how;
        
        }

        Pages chooseLeast() {
            Pages tp;
           // Pages big;
            int most=-1;
            int idx=0;
            for (int i=0; i<pages.size(); i++) {
                if (pages[i].time>most) {
                    most=pages[i].time;
                    
                    tp=pages[i];
                    idx=i;
                } else if (pages[i].time==most) {
                    if(pages[i].aid<tp.aid) {
                        tp=pages[i];
                        idx=i;

                    }
                }
            }

            pages.erase(pages.begin()+idx);
            return tp;
        }

        int calcBinaryNum(queue<int> a) {
            
            int sum=0;
            for (int i=0; i<8; i++) {
                ////cout<<a.front()<<" ";
                sum+=(int)a.front()*pow(2,i);
                a.pop();
            }
            ////cout<<endl;
            return sum;
        }

        Pages lruSelect() {
            int min=20000;
            bool ss=false;
            Pages minP;
            int idx=0;
        
            for (int i=0; i<pages.size(); i++) {
                if (pages[i].r==0) {
                    ss=true;
                    break;
                }
            }

            if (ss) {
                for (int i=0; i<pages.size(); i++) {
                    if (pages[i].r==0) {
                        queue<int> temp=pages[i].refByte;
                        if (calcBinaryNum(temp)<min) {
                            min=calcBinaryNum(temp);
                            minP=pages[i];
                            minP.refByte=pages[i].refByte;
                            idx=i;
                        }
        
                    }
                }
            } else {
                for (int i=0; i<pages.size(); i++) {
                    queue<int> temp=pages[i].refByte;
                    ////cout<<pages[i].aid<<"   :   "<<calcBinaryNum(temp)<<endl;
                    if (calcBinaryNum(temp)<min) {
                        min=calcBinaryNum(temp);
                        minP=pages[i];
                        minP.refByte=pages[i].refByte;

                        idx=i;
                    } else if (calcBinaryNum(temp)==min) {
                        if(pages[i].aid<minP.aid) {
                            minP=pages[i];
                            minP.refByte=pages[i].refByte;
                            
                            idx=i;
                        }
                    }

                
                }
            }
                    
            pages.erase(pages.begin()+idx);
            
            return minP;
        }

        int lruS(Memory *PM, Memory *VM, int demandSize, int aid, int idx) {
            int how=0;
            int one=0;
            while (true) {
                ////cout<<"cur page size is  : "<<pages.size()<<endl;
                for (int i=0; i<pages.size(); i++) {
                    ////cout<<pages[i].aid<<endl;
                }

                how++;
                Pages tp=lruSelect();

                ////cout<<"after select   cur page size is  : "<<pages.size()<<endl;
                for (int i=0; i<pages.size(); i++) {
                    ////cout<<pages[i].aid<<endl;
                }

                tp.PMblock->aid=-1;
                flushMem(PM, VM, tp.PMblock);

                if ( mergeCheck(PM, VM, tp.PMblock)) {
                    ////cout<<"!!!!!!!!!!!!!!!!!!"<<endl;
                    merge(tp.PMblock, PM, VM);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;
                    ////cout<<"result aid is : "<<result->aid<<endl;
                    ////cout<<"result aid is : "<<resAid<<endl;


                    if ( resAid!=-10) {
                        ////cout<<"here!!!!!"<<endl;
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                        Pages tempPage;
                        pages.push_back(tempPage);
                        pages.back().aid=aid;
                        pages.back().PMblock=result;
                        pages.back().time=0;
                        pages.back().count=1;
                        pages.back().opt=0;
                        //int zero=0;
                        pages.back().r=1;
                    // pages.back().refByte=zeroQ;
                        for (int z=0; z<8; z++) {
                            pages.back().refByte.push(0);
                        }
                     //   pages.push_back(tempPage);
                        ////cout<<pages.back().aid<<endl;

                        break;
                    }
                } else {
                    flushMem(PM, VM, tp.PMblock);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;
                    int *k=&result->aid;
                    if ( *k!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);


                           Pages tempPage;
                            pages.push_back(tempPage);
                            pages.back().aid=aid;
                            pages.back().PMblock=result;
                            pages.back().time=0;
                            pages.back().count=1;
                            pages.back().opt=0;
                            //int zero=0;
                            pages.back().r=1;
               // pages.back().refByte=zeroQ;
                            for (int z=0; z<8; z++) {
                                pages.back().refByte.push(0);
                            }
                            //  pages.push_back(tempPage);
                   
                        break;
                    }
                }
            }
            return how;
        }

        int lru(Memory *PM, Memory *VM, int demandSize, int aid, int idx) {
            int how=0; 
            while (true) {
                how++;
                Pages tp=chooseLeast();
                tp.PMblock->aid=-1;
                flushMem(PM, VM, tp.PMblock);
                if ( mergeCheck(PM, VM, tp.PMblock)) {
                    merge(tp.PMblock, PM, VM);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;
                    if ( resAid!=-10 ) {
                        ////cout<<"res is not -10"<<endl;
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                         Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=1;
               // pages.back().refByte=zeroQ;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                } else {
                    flushMem(PM, VM, tp.PMblock);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                         Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=1;
               // pages.back().refByte=zeroQ;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                }
            }
            return how;
        
        }

        int fifo(Memory *PM, Memory *VM, int demandSize, int aid, int idx) {
            int how=0;
            while (true) {
                how++;
                Pages tp=pages.front();
               // //////cout<<tp.aid<<endl;
                //pages.remove()
                pages.erase(pages.begin());
                //////cout<<"here!!"<<pages.front().aid<<endl;
                tp.PMblock->aid=-1;
                flushMem(PM, VM, tp.PMblock);
                if ( mergeCheck(PM, VM, tp.PMblock)) {
                    //////cout<<"!!!!!!!!!!!!!!!!!!"<<endl;
                    merge(tp.PMblock, PM, VM);
                    Node* result=search(rootPtr, demandSize, aid);
                   int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;

                        fillMem(result, PM, VM, idx);
                       Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=1;
               // pages.back().refByte=zeroQ;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                } else {
                    flushMem(PM, VM, tp.PMblock);
                    Node* result=search(rootPtr, demandSize, aid);
                    int resAid=result->aid;

                    if ( resAid!=-10 ) {
                        result->aid=aid;
                        fillMem(result, PM, VM, idx);
                       Pages tempPage;
                pages.push_back(tempPage);
                pages.back().aid=aid;
                pages.back().PMblock=result;
                pages.back().time=0;
                pages.back().count=1;
                pages.back().opt=0;
                //int zero=0;
                pages.back().r=1;
               // pages.back().refByte=zeroQ;
               for (int z=0; z<8; z++) {
                   pages.back().refByte.push(0);
               }
                        break;
                    }
                }
            }
            return how;
        }


        

};

#endif