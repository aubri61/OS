#ifndef MEMORY
#define MEMORY

#include <vector>
#include <iostream>

using namespace std;
struct Memory{
    int memSize;
    vector<vector<int> > memTable;
};

struct LockVal{
    int id;
    bool locked;
    int pid;
};
//void createTable(int a, int b, bool t, Memory mem) {
//     mem.memSize=a/b;
//     mem.memTable.reserve(mem.memSize);
        
//     for(int i=0; i<mem.memSize; i++) {
//         mem.memTable[i].reserve(3);
//         mem.memTable[i][0]=-1;
//         if (t) {
//             mem.memTable[i][1]=i;
//         } else {
//             mem.memTable[i][1]=-1;
//         }
//         mem.memTable[i][2]=0;
//     }
// }

// class Memory{
//     public :
//         int memSize;
//         vector< vector<int> > memTable;

//         Memory() {
//             memSize=0;
//             memTable.reserve(1);
//             memTable[0].reserve(1);
//         }

//         Memory(int a, int b, bool t) {
//             cout<<"entered"<<endl;
            
//             memSize=a/b;

//             memTable.reserve(memSize);
//          //   cout<<memSize<<endl;
//             for(int i=0; i<memSize; i++) {
//                 memTable[i].reserve(3);
//                 memTable[i][0]=-1;
//                 if (t) {
//                     memTable[i][1]=i;
//                 } else {
//                     memTable[i][1]=-1;
//                 }
//                 memTable[i][2]=0;
//             }
//             // memTable=new int*[memSize];
//             // for (int i=0; i<memSize; i++) {
//             //     memTable[i]=new int[4];
//             // }
//         }

//         void reassign(int a, int b) {
//             //int temp=a;
//             // cout<<a<<endl;
//             // cout<<b<<endl;
//             // cout<<temp/b<<endl;

//             memSize=a/b;

//             memTable.reserve(memSize);
//          //   cout<<memSize<<endl;
//             for(int i=0; i<memSize; i++) {
//                 memTable[i].reserve(3);
//                 memTable[i][0]=-1;
//                 memTable[i][1]=-1;
                
//                 memTable[i][2]=0;
//             }
//         }
// };

#endif