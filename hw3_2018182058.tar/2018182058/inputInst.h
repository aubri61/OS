#ifndef INPUTINST
#define INPUTINST


#include <iostream>
using namespace std;

struct inputInst{
    int cycleTime;
    string codename;
    int IOpid;
};

#endif