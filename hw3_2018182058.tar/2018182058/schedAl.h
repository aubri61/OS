#ifndef SCHEDAL
#define SCHEDAL

#include "options.h"
#include "process.h"
#include "inputInst.h"


int calcExBurst(Process *process);
int calcExBurstExp(Process *process);

void scheduler(Process *procList, vector<inputInst> inputInstList, Options options, int procnum, FILE *schedout, FILE *memout, vector<pair<int, int> > accessCodeList);


#endif
