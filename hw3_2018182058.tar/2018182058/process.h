#ifndef PROCESS
#define PROCESS

#include "codeInst.h"
#include "memory.h"



struct Process{
    int startTime;
    string procName;
    int pid;
    int burst;
    int exBurst;
    int preExBurst;
    int sleepCycle;
    int where;
    int timeQuant;

    LockVal lockingVal;

    bool IOwait;
    bool sleep;
    bool busywaiting;
    bool timeQuantAllUsed;
    bool created;
    bool done;
    vector<int> burstList;
    vector<codeInst> codeList;
   
    Memory pageTable;
    Memory *vmptr;
};

#endif