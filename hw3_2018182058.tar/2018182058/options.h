#ifndef OPTIONS
#define OPTIONS

#include <iostream>
#include <queue>

using namespace std;

struct Options{
    queue<pid_t> runQ;
    string sched, page, dir;
    int totalEventNum, vmemSize, pmemSize, pageSize;
};

#endif