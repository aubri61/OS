#ifndef CODEINST
#define CODEINST

struct codeInst {
    int  opcode, arg;
};

#endif