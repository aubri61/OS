#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <chrono>

using namespace std;

int main(int argc, char *argv[]) {
    //get original process number
    int oriProNum=atoi(argv[1]);
    int pronum;
    int fil_num, fil_row, fil_col;
    //getting filter informations
    cin >> fil_num >> fil_row >> fil_col;
    int filter[fil_num][3][fil_row][fil_col];

    //If the number of original process number is smaller bigger than filter number,
    //set pronum as filter number. If not, pronum equals to oriProNum.
    if (oriProNum>fil_num) {
        pronum=fil_num;
    } else {
        pronum=oriProNum;
    }
    
    //store filter data
    for (int i=0; i<fil_num; i++) {
        for (int j=0; j<3; j++) {
            for (int k=0; k<fil_row; k++) {
                for (int l=0; l<fil_col; l++) {
                    cin >> filter[i][j][k][l];
                }
            }
        }
    }

    //set input array.
    //it will be the data that will be tossed to program1 as input,
    //so it does not have to be widen by (row+2)*(col+2)
    //just store the values
    int row, col;
    cin >> row >> col;
    int input[3][row][col];

    for (int i=0; i<3; i++) {
        for (int j=0; j<row; j++) {
            for (int k=0; k<col; k++) {
                cin >> input[i][j][k];
            }
        }
    }

    //arrays of filename
    string inS[pronum];
    string outS[pronum];

    //to divide filter input, let q be the quotient of filnum/pronum
    //let rem be the remainder of filnum/pronum.
    int q=fil_num/pronum;
    int rem=fil_num%pronum;
    //idx stroes which filter should be allocated
    //kind of pointer of starting point
    int idx=0;
    for (int i=0; i<pronum; i++) {
        //set names of files
        string s="tempinput"+to_string(i);
        string t="tempoutput"+to_string(i);
        inS[i]=s;
        outS[i]=t;
        //make two files. outFile stores distributed input data
        //out will store calculation data done by program1
        ofstream outFile(s);
        ofstream out(t);
        out.close();
        //if rem>0, outFile will have (q+1) number of filters.
        //after setting filters, do rem-- so that filter input can be correctly divided.
        if (rem>0) {
            //stroing filter data
            outFile<<q+1<<" "<<fil_row<<" "<<fil_col<<"\n";
            for (int x=0; x<q+1; x++) {
                for (int j=0; j<3; j++) {
                    for (int k=0; k<fil_row; k++) {
                        for (int l=0; l<fil_col; l++) {
                            outFile<<filter[x+idx][j][k][l]<<" ";
                        }
                        outFile<<"\n";
                    }
                }
            }
            //move the idx to next starting point
            idx+=q+1;
            //storing input data
            outFile<<row<<" "<<col<<"\n";
            for (int i=0; i<3; i++) {
                for (int j=0; j<row; j++) {
                    for (int k=0; k<col; k++) {
                        outFile << input[i][j][k]<<" ";
                    }
                    outFile<<"\n";
                }
            }
            outFile.close();
            rem--;
        } else {
        //if !(rem>0), outFile will have (q) number of filters.
        //storing filter data
           outFile<<q<<" "<<fil_row<<" "<<fil_col<<"\n";
            for (int x=0; x<q; x++) {
                for (int j=0; j<3; j++) {
                    for (int k=0; k<fil_row; k++) {
                        for (int l=0; l<fil_col; l++) {
                            outFile<<filter[x+idx][j][k][l]<<" ";
                        }
                        outFile<<"\n";
                    }
                }
            }
            //move idx
            idx+=q;
            //storing input data
            outFile<<row<<" "<<col<<"\n";
            for (int i=0; i<3; i++) {
                for (int j=0; j<row; j++) {
                    for (int k=0; k<col; k++) {
                        outFile << input[i][j][k]<<" ";
                    }
                    outFile<<"\n";
                }
            }
            outFile.close();
        }
    }

    //start checking time
    chrono::system_clock::time_point Start=chrono::system_clock::now();

    //make array of pid as number of pronum
    pid_t pids[pronum], terminatedChild;
    int childStatus;
    int i;
    for (i=0; i<pronum; i++) {
        //make child process
        pids[i]=fork();
        //if child process
        if (pids[i]==0) {
            int in, out;
            char *args[] = {(char*)"./program1", NULL};
            in=open(inS[i].c_str(), O_RDONLY);
            out=open(outS[i].c_str(), O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR);
            dup2(in, 0);
            dup2(out,1);
            close(in);
            close(out);
            execvp("./program1",args);
        } 
    }
    //wait until the child processes end
    for (i=0; i<pronum; i++) {
        pid_t terminatedChild=wait(&childStatus);
    }
    //stop checking time
    chrono::system_clock::time_point End=chrono::system_clock::now();

    chrono::milliseconds mill=chrono::duration_cast<chrono::milliseconds>(End-Start); 

    //times array that will contain each time taken in process
    //first initialize times with 0
    int times[oriProNum];
    for (i=0; i<oriProNum; i++) {
        times[i]=0;
    }
    
    //now print the output file and store time taken in each process to times[i]
    for (i=0; i<pronum; i++) {
        //every line in file
        string line;
        //reading outputfile
        ifstream read(outS[i].c_str());
       
        //read nextline
        while(getline(read,line)) {
            //if next line is end of file, then put next line to times and break
            if (read.peek()==EOF) {
                getline(read, line);
                //convert string to int
                times[i]=stoi(line);
                break;
            }
            cout << line <<endl;
        }
    }

    //printing processing times
    for (i=0; i<oriProNum; i++) {
        cout << times[i]<<" ";
    }
    cout<<"\n";
    cout<<mill.count()<<endl;

    //removing files
    for (int i=0; i<pronum; i++) {
        remove(inS[i].c_str());
        remove(outS[i].c_str());
    }
  
    return 0;
}
