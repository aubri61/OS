#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <vector>
#include <chrono>

using namespace std;

//making new class Filter that will hold devided filter informations
class Filter {
    public :
        int filnum;
        int filrow;
        int filcol;
        vector<vector<vector<vector<int>>>> filter;

        //setting filter value to int val
        void set_Filter(int a, int b, int c, int d, int val) {
           filter[a][b][c][d]=val;
        }
        //defualt constructor
        Filter() {
            filnum=0;
            filrow=0;
            filcol=0;
        }

        Filter(int filn, int filr, int filc){
            filnum=filn;
            filrow=filr;
            filcol=filc;
            vector<vector<vector<int>>> f;
            vector<vector<int>> fr;
            vector<int> fc(filcol);
            f.reserve(filn);
            fr.reserve(filr);
            fc.reserve(filc);
            for (int i=0; i<filnum; i++) {
                for (int k=0; k<3; k++) {
                    for (int j=0; j<filrow; j++) {
                        fr.push_back(fc);
                    }
                    f.push_back(fr);
                }
                filter.push_back(f);
            }
        }
};

//struct will be data that will send to t_function when pthread create is called
//contains information that will be needed in CNN calculating or saving output for calculation
struct thread_data {
    int inputrow;
    int inputcol;
    long time;
    int maprow;
    int mapcol;
    Filter tempfil;
    //output will hold the result of calculation
    vector<vector<vector<int>>> output;
    vector<vector<vector<int>>> input;
};

void *t_function(void *data) {
    struct thread_data *temp=(struct thread_data*)data;
    Filter tempfil=temp->tempfil;
    int filnum=temp->tempfil.filnum;
    int filrow=temp->tempfil.filrow;
    int filcol=temp->tempfil.filcol;
    int maprow=temp->maprow;
    int mapcol=temp->mapcol;
    int inputrow=temp->inputrow;
    int inputcol=temp->inputcol;

    temp->tempfil=tempfil;
    
    vector<vector<vector<int>>> output=temp->output;
    vector<vector<vector<int>>> input=temp->input;

    //since calculation starts from here, check time from now on.
    chrono::system_clock::time_point Start=chrono::system_clock::now();
    //making maps. every filter
    for (int i=0; i<filnum; i++) {
        //every channel
        for (int j=0; j<3; j++) {
            //every row
            for (int k=0; k<maprow; k++) {
                //every col
                for (int l=0; l<mapcol; l++) {
                    //move filter
                    for (int x=0; x<filrow; x++) {
                        for (int y=0; y<filcol; y++) {
                            //calculate(add to output) all at once
                            output[i][k][l]+=tempfil.filter[i][j][x][y]*input[j][x+k][y+l];
                        }
                    }
                }
            }
        }
    }

    //do ReLu
    for (int x=0; x<filnum; x++) {
        for (int i=0; i<maprow; i++) {
            for (int j=0; j<mapcol; j++) {
                if (output[x][i][j]<=0) output[x][i][j]=0;
            }
        }
    } 
    chrono::system_clock::time_point End=chrono::system_clock::now();

    chrono::milliseconds mill=chrono::duration_cast<chrono::milliseconds>(End-Start); 
    //save the output to temp->output
    temp->output=output;
    temp->time=mill.count();
    //return the temp struct to main function
    pthread_exit(temp);
}

int main(int argc, char *argv[]) {
    
    //get original threads number
    int oriThNum=atoi(argv[1]);
    int thnum;
    //getting filter informations
    int fil_num, fil_row, fil_col;
    cin >> fil_num >> fil_row >> fil_col;

    //If the number of original threads number is smaller bigger than filter number,
    //set thread num(thnum) as filter number. If not, thnum equals to oriThnum.
    if (oriThNum>fil_num) {
        thnum=fil_num;
    } else {
        thnum=oriThNum;
    }

    //declare array of thread_data struct 
    thread_data splits[thnum];
    
    //to divide filter input, let q be the quotient of filnum/thnum
    //let rem be the remainder of filnum/thnum.
    int q=fil_num/thnum;
    int rem=fil_num%thnum;

    //declare new Filter class instance
    Filter tempf;
    for (int x=0; x<thnum; x++) {
        //if rem>0, splits[x] will have (q+1) number of filters.
        //after setting filters, do rem-- so that filter input can be correctly divided.
        if (rem>0) {
            tempf=Filter(q+1, fil_row, fil_col);
            for (int i=0; i<q+1; i++) {
                for (int j=0; j<3; j++) {
                    for (int k=0; k<fil_row; k++) {
                        for (int l=0; l<fil_col; l++) {
                            int val;
                            cin >> val;
                            tempf.set_Filter(i, j, k, l, val);
                        }
                    }
                }
            }
            //set filter of splits[x] as tempf;
            splits[x].tempfil=tempf;
            rem--;
        } 
        //if rem is not bigger than 0, splits[x] will have (q) nummber of filters.
        else {
            tempf=Filter(q, fil_row, fil_col);
            for (int i=0; i<q; i++) {
                for (int j=0; j<3; j++) {
                    for (int k=0; k<fil_row; k++) {
                        for (int l=0; l<fil_col; l++) {
                            int val;
                            cin >> val;
                            tempf.set_Filter(i, j, k, l, val);
                        }
                    }
                }
            }
            //set filter of splits[x] as tempf;
            splits[x].tempfil=tempf;
        }
    }

    //getting data and make padding around the data.
    int row, col;
    cin >> row >> col;
    vector<vector<vector<int>>> input;
    vector<vector<int>> r;
    vector<int> c(col+2);
    c.reserve(col+2);
    r.reserve(row+2);
    input.reserve(3);
    //making row+2 *col+2 size vector consists of 0.
    for (int i=0; i<3; i++) {
        for (int j=0; j<row+2; j++) {
            r.push_back(c);
        }
        input.push_back(r);
    }
    //getting input data
    for (int i=0; i<3; i++) {
        for (int j=1; j<row+1; j++) {
            for (int k=1; k<col+1; k++) {
                cin >> input[i][j][k];
            }
        }
    }

    //making maps consists of 0
    int maprow=row+2-fil_row+1;
    int mapcol=col+2-fil_col+1;
    vector<vector<vector<int>>> maps1;
    vector<vector<vector<int>>> maps2;
    vector<vector<int>> mr;
    vector<int> mc(mapcol);
    mc.reserve(mapcol);
    mr.reserve(maprow);
    maps1.reserve(q+1);
    maps2.reserve(q);
    for (int i=0; i<q; i++) {
        for (int j=0; j<maprow; j++) {
            mr.push_back(mc);
        }
        maps1.push_back(mr);
        maps2.push_back(mr);
    }
    maps1.push_back(mr);

    //set values and data to array of sturct splits according to their number(i)
    for (int i=0; i<thnum; i++) {
        if (splits[i].tempfil.filnum==(q+1)) {
            splits[i].output=maps1;
        } else {
            splits[i].output=maps2;
        }
        splits[i].input=input;
        splits[i].inputcol=col;
        splits[i].inputrow=row;
        splits[i].time=0;
        splits[i].mapcol=mapcol;
        splits[i].maprow=maprow;
    }

    //start checking time
    chrono::system_clock::time_point Start=chrono::system_clock::now();
    //thread pool number of thnum
    pthread_t p_thread[thnum];
    for (int i=0; i<thnum; i++) {
        //thread create. send sturct for their number(i) to t_function
        pthread_create(&p_thread[i], NULL, t_function, (void *)&splits[i]);
    }
    //declare new array of struct thread_data 
    //that will contain the result of thread job done in t_function
    struct thread_data* results[thnum];
    for (int i=0; i<thnum; i++) {
        void* result;
        //get return value of t_function to result
        //and push it to results[i]
        pthread_join(p_thread[i], &result);
        struct thread_data* tttt=(struct thread_data*)result;
        results[i]=tttt;
    }
    //stop checking time
    chrono::system_clock::time_point End=chrono::system_clock::now();
   
    chrono::milliseconds mill=chrono::duration_cast<chrono::milliseconds>(End-Start); 
 
    //times array that will contain each time taken in threads
    int times[oriThNum]={0,};
    for (int i=0; i<thnum; i++) {
        //time of result[i] will be times[i] 
        times[i]=results[i]->time;
        for (int x=0; x<results[i]->tempfil.filnum; x++) {
            for (int y=0; y<maprow; y++) {
                for (int j=0; j<mapcol; j++) {
                    //print each value of output
                    cout << results[i]->output[x][y][j]<<" ";
                }
                cout << "\n";
            }
            cout <<"\n";
        }
    }

    //printing time taken in each threads
    for (int i=0; i<oriThNum; i++) {
        cout<<times[i]<<" ";
    }
    cout<<"\n";
    //printing time taken in program3
    cout << mill.count()<<endl;

    return 0;
}
