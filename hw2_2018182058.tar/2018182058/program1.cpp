#include <iostream>
#include <string>
#include <stdio.h>
#include <vector>
#include <chrono>

using namespace std;

int main() {
  
    int fil_num, fil_row, fil_col;
    
    //getting filter informations
    //fil_num=the number of filters, fil_row=number of rows of filter, fil_col=number of cols fo filter
    cin >> fil_num >> fil_row >> fil_col;
    vector<vector<vector<vector<int>>>> filter;
    vector< vector< vector< int> > > fchan;
    vector< vector< int> > frow;
    vector< int > fcol;
    fcol.reserve(fil_col);
    frow.reserve(fil_row);
    fchan.reserve(3);
    filter.reserve(fil_num);
    //filling filter vector with cin 
    for (int i=0; i<fil_num; i++) {
        for (int j=0; j<3; j++) {
            for (int k=0; k<fil_row; k++) {
                for (int l=0; l<fil_col; l++) {
                    int val;
                    cin >> val;
                    //every iteration each vectors should be cleard so that new values can be stored
                    fcol.push_back(val);
                }
                frow.push_back(fcol);
                fcol.clear();
            }
            fchan.push_back(frow);
            frow.clear();
        }
        filter.push_back(fchan);
        fchan.clear();
    }

    //getting input data information
    //irow=row num of data , icol=col num of data
    int irow, icol;
    cin >> irow>>icol;

    vector<vector<vector<int>>> input;
    vector<vector<int>> r;
    vector<int> c(icol+2);
    //c.reserve(icol+2);
    r.reserve(irow+2);
    input.reserve(3);

    //set padding first. make (row+2)*(col+2) dataset first filled with 0
    for (int i=0; i<3; i++) {
        for (int j=0; j<irow+2; j++) {
            r.push_back(c);
        }
        input.push_back(r);
    }
    //and then set data values
    for (int i=0; i<3; i++) {
        for (int j=1; j<irow+1; j++) {
            for (int k=1; k<icol+1; k++) {
                cin >> input[i][j][k];

            }
        }
    }
    
    //maps=output data(that will store the result of calculation)
    //initialize maps
    int maprow=irow+2-fil_row+1;
    int mapcol=icol+2-fil_col+1;

    vector<vector<vector<int>>> maps;
    vector<vector<int>> mr;
    vector<int> mc(mapcol);
    //mc.reserve(mapcol);
    mr.reserve(maprow);
    maps.reserve(fil_num);

    for (int i=0; i<fil_num; i++) {
        for (int j=0; j<maprow; j++) {
            mr.push_back(mc);
        }
        maps.push_back(mr);
    }

    //start checking time
    chrono::system_clock::time_point Start=chrono::system_clock::now();
    for (int i=0; i<fil_num; i++) {
        //every channel
        for (int j=0; j<3; j++) {
            //every row
            for (int k=0; k<maprow; k++) {
                //every col
                for (int l=0; l<mapcol; l++) {
                    //moving filter
                    for (int x=0; x<fil_row; x++) {
                        for (int y=0; y<fil_col; y++) {
                            //adding all at once
                            maps[i][k][l]+=filter[i][j][x][y]*input[j][x+k][y+l];
                        }
                    }
                }
            }
        }
    }


    //do ReLu
    for (int x=0; x<fil_num; x++) {
        for (int i=0; i<maprow; i++) {
            for (int j=0; j<mapcol; j++) {
                if (maps[x][i][j]<=0) maps[x][i][j]=0;
            }
        }
    }
    //stop checking time
    chrono::system_clock::time_point End=chrono::system_clock::now();
    //store the time taken
    chrono::milliseconds mill=chrono::duration_cast<chrono::milliseconds>(End-Start); 
    
    //print the result
    for (int x=0; x<fil_num; x++) {
        for (int i=0; i<maprow; i++) {
            for (int j=0; j<mapcol; j++) {
                cout << maps[x][i][j]<<" ";
            }
            cout << "\n";
        }
        cout <<"\n";
    }
   
    //print time taken
    cout <<mill.count()<<endl;

    return 0;
}